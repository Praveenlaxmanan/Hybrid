package com.framework.reports;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ExtentReports {


	com.relevantcodes.extentreports.ExtentReports reports;
	ExtentTest testLogger;
	
	public void intializeReportConfigs(){
		
		
		
	}
	
	
	
	
	
	public void reportPASS(String testInfo){
		
		testLogger.log(LogStatus.PASS, testInfo);
	}
	
	public void reportFAIL(String testInfo){
		
		testLogger.log(LogStatus.FAIL, testInfo);
		
	}
	
	
	public void reportINFO(String testInfo){
		
		testLogger.log(LogStatus.INFO, testInfo);
		
	}
	
	public void reportERROR(String testInfo){
		
		testLogger.log(LogStatus.ERROR, testInfo);
		
	}
	
	
	public void reportWARNING(String testInfo){
		
		testLogger.log(LogStatus.WARNING, testInfo);
		
	}
	
	
	public void reportFailScreenshot(WebDriver driver, String testMessage, boolean screenshotStatus){
		
		if(screenshotStatus){
			
			
			String screenshotName = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss_a").format(new Date());
			
//			if(new File(arg0))
			
			
		}
		
		
	}
	
	
	
	
	
}