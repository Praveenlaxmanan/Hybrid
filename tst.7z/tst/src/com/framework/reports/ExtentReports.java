package com.framework.reports;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ExtentReports {


	com.relevantcodes.extentreports.ExtentReports reports;
	ExtentTest testLogger;
	
	public void intializeReportConfigs(){
		
		
		
	}
	
	
	
	
	
	public void reportPASS(String testInfo){
		
		testLogger.log(LogStatus.PASS, testInfo);
	}
	
	public void reportFAIL(String testInfo){
		
		testLogger.log(LogStatus.FAIL, testInfo);
		
	}
	
	
	public void reportINFO(String testInfo){
		
		testLogger.log(LogStatus.INFO, testInfo);
		
	}
	
	public void reportERROR(String testInfo){
		
		testLogger.log(LogStatus.ERROR, testInfo);
		
	}
	
	
	public void reportWARNING(String testInfo){
		
		testLogger.log(LogStatus.WARNING, testInfo);
		
	}
	
	
	
	
	
}