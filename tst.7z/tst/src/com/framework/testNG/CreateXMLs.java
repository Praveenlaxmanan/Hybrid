package com.framework.testNG;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.TransformerFactory;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.collections.Lists;
import org.testng.collections.Maps;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.framework.libraries.ExcelReader;

public class CreateXMLs {
	public ExcelReader getSuiteExcel;
	
	private static Logger logInfo = Logger.getLogger(CreateXMLs.class.getName());
	private static Properties parallelConfig;
	
	static int testcaseXMLSplitCount = 0;
	
	
	public void createTestcaseXML(String testcaseID, String testcaseDesc, String moduleName, String testAuthor){
		
		try{
			DocumentBuilderFactory docBulFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBulFactory.newDocumentBuilder();
			Document document = docBuilder.newDocument();
			Element rootElement = null;
			
			rootElement = document.createElement("suite");
			rootElement.setAttribute("name", "Testcases");
			rootElement.setAttribute("parallel", "tests");
			rootElement.setAttribute("thread-count", "3");
			
			Element parameterName = document.createElement("parameter");
			parameterName.setAttribute("name", "suiteType");
			parameterName.setAttribute("value", "Parallel");
			rootElement.appendChild(parameterName);
			document.appendChild(rootElement);
			
			//Append test case details in TestNG XML files
			
			Element test = document.createElement("test");
			test.setAttribute("name", testcaseID);
			rootElement.appendChild(test);
			
			Element parameter = document.createElement("parameter");
			parameter.setAttribute("name", "testcaseID");
			parameter.setAttribute("value", testcaseID);
			test.appendChild(parameter);
			
			Element parameter2 = document.createElement("parameter");
			parameter2.setAttribute("name", "testcaseDesc");
			parameter2.setAttribute("value", testcaseDesc);
			test.appendChild(parameter2);
			
			Element parameter3 = document.createElement("parameter");
			parameter3.setAttribute("name", "moduleName");
			parameter3.setAttribute("value", moduleName);
			test.appendChild(parameter3);
			
			Element parameter4 = document.createElement("parameter");
			parameter4.setAttribute("name", "testAuthor");
			parameter4.setAttribute("value", testAuthor);
			test.appendChild(parameter4);
			
			Element classes = document.createElement("classes");
			test.appendChild(classes);
			
			Element singleClass = document.createElement("class");
			singleClass.setAttribute("name", "com.framework.libraries.Wrappers");
			classes.appendChild(singleClass);
			
			Element method = document.createElement("methods");
			singleClass.appendChild(method);
			
			Element include = document.createElement("include");
			include.setAttribute("name", "getSuite");
			method.appendChild(include);
			
			
			TransformerFactory transFactory = TransformerFactory.newInstance();
			
			
		}catch(Exception e){
			
			
			
		}
		
		
		
	}
	
	public void initializeSuiteExcel(){
		
		try{
		//Initialize Environment Excel Sheet
			getSuiteExcel = new ExcelReader("Configurations/Test_Setup/Test_Suite.xlsx", parallelConfig.getProperty("suiteName"));
		System.out.println("*** suiteExcel ***:" +getSuiteExcel.getSheetName());
		}catch(Exception e){
			
			System.out.println("Suite excel sheet is not available in Configuration folder");
		}
	}
	
	
	public Map<String, List<String>> getSuite(){
		
		
		
		try{
			
			for(int i = 1; i < getSuiteExcel.getNoOfRows(); i++){
				
				String executeFlag = getSuiteExcel.getDataByColumn(i, "Execute");
				
				if(executeFlag.equalsIgnoreCase("Yes")){
					
					String testcaseID = getSuiteExcel.getDataByColumn(i, "Test_Case_ID");
					String executionType = getSuiteExcel.getDataByColumn(i, "Execution_Type");
					String testcaseDesc = getSuiteExcel.getDataByColumn(i, "Testcase_Description");
					String moduleName = getSuiteExcel.getDataByColumn(i, "Component_SheetName");
					String testAuthor = getSuiteExcel.getDataByColumn(i, "TestAuthor");
					
					System.out.println("caseID :"+testcaseID);
					System.out.println("executionType :"+executionType);
					System.out.println("testcaseDesc :"+testcaseDesc);
					System.out.println("moduleName :"+moduleName);
					System.out.println("moduleName :"+testAuthor);
					
				}
				
			}
			
			
		}catch(Exception e){
			
			
			
		}
		
		
		return null;
		
		
	}
	
	public static void main(String[] args) {
		
		try{
			
			//Initialized parallel configuration property file
			parallelConfig = new Properties();
			parallelConfig.load(new FileInputStream(new File("./src/com/framework/properties/parallelConfig.properties")));
			
			//Initialized Log4j config file
			String log4jConfigPath = parallelConfig.getProperty("Log4jConfigFile");
			PropertyConfigurator.configure(log4jConfigPath);
			logInfo.info("********* Convert Test Cases to TestNG XML Files ***********\n");
			
			//Split the test cases in XML by given in parallel configuration property file
			String testcaseSplitCount = parallelConfig.getProperty("testCaseSplitCount");
			testcaseXMLSplitCount = Integer.parseInt(testcaseSplitCount);
			logInfo.info("Splitted test case count :"+testcaseXMLSplitCount);
			
		}catch(Exception e){
			
			e.printStackTrace();
			
		}
		
		CreateXMLs test = new CreateXMLs();
		test.initializeSuiteExcel();
		test.getSuite();
		
		
	}
	

}
