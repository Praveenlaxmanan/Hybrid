package group;

public class Groups implements Runnable{

	public void run() {

		System.out.println("Thread 1: "+Thread.currentThread().getName());
		
	}

	
	public static void main(String[] args) {
		

	Groups gro = new Groups();
	
	ThreadGroup tg1 = new ThreadGroup("Thread Groups");
	Thread t1 = new Thread(tg1, gro, "one");
	t1.start();
	
	Thread t2 = new Thread(tg1, gro, "two");
	t2.start();
	
	Thread t3 = new Thread(tg1, gro, "Three");
	t3.start();
	
	System.out.println("Thread Group name: "+tg1.getName());
	
	tg1.list();
	
	
	
	}
}
