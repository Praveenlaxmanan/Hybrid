package group;

public class JoinDemo {

	public static void main(String[] args) throws InterruptedException {

		MythreadDemo t = new MythreadDemo();
		t.start();

		
		for(int i=0;i<10;i++){
			Thread.sleep(1000);
			Thread.currentThread();
		System.out.println("Praveen");}
		
		
	}

}
