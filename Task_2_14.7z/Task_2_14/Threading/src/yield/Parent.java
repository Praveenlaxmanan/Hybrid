package yield;

public class Parent {

	public static void main(String[] args) throws InterruptedException {

		Child1 c1 = new Child1();
		//c1.setPriority(2);
		c1.start();
		
		
		Child2 c2 = new Child2();
		//c2.setPriority(7);
		c2.start();
		
		Child3 c3 = new Child3();
		//c3.setPriority(10);
		c3.start();
		
		for(int i=0; i<10; i++){
			
			System.out.println("Main method ");
			
		}
		
		
		
	}
	

}
