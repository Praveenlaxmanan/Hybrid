package join;

public class Parent {

	public static void main(String[] args) throws InterruptedException {

		Child2 c2 = new Child2();
		c2.start();
		c2.join();
		System.out.println("Name "+c2.getName());
		c2.setName("Setting name for child 2");
		System.out.println(c2.getName());
		
		Child1 c1 = new Child1();
		c1.start();
		System.out.println("Name "+c1.getName());
		System.out.println("Id "+c1.getId());

		
		Child3 c3 = new Child3();
		c3.start();
		System.out.println("Name "+c3.getName());
		System.out.println("Id "+c3.getId());


		
		
	}

}
