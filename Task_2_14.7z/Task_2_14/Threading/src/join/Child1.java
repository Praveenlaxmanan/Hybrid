package join;

public class Child1 extends Thread {

	
	public void run(){
		
		
		for(int i=0; i<10; i++){
			
			System.out.println("Child 1 "+i);
			
		}
		
		
		
		
	}
	

}
