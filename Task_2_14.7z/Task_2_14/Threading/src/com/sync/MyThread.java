package com.sync;

public class MyThread extends Thread {
	Sample s;
	String name;
	
	MyThread(Sample s,String name){
		
		this.s=s;
		this.name=name;
	}
	
	public void run(){
		
		s.wish(name);
	}
	
}
