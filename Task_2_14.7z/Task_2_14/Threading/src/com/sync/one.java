package com.sync;

public class one {


	public synchronized void testone(String name1) throws InterruptedException{
		
		for (int i = 0; i < 10; i++) {
			
			Thread.sleep(2000);
			
			System.out.print("Yes I am ");
			
			System.out.println(name1);
			
			
		}
		
		
	}
	
	
	
}
