package com.sync;

public class Sample {

	public synchronized void wish(String name){
		
		for(int i =0; i<5; i++){
			
			
			try{
				Thread.sleep(2000);

				System.out.print("Good morning ");

				System.out.println(name);


			} catch(Exception e){
				
				
			}
			
		}
		
		
	}
	
	
	
}
