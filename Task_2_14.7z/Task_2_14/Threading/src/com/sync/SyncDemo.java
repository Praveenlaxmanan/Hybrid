package com.sync;

public class SyncDemo {

	public static void main(String[] args) {

		Sample s1= new Sample();
		MyThread t = new MyThread(s1,"Praveen");
		MyThread t1 = new MyThread(s1,"Hari");

		t.start();
		t1.start();
	}
	
}