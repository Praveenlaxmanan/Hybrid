package com.sync;

public class Three {

	public static void main(String[] args) {

		one on1 = new one();
		two t1 = new two(on1, null);
		two t2 = new two(on1, null);
		
		t1.start();
		t2.start();
		
		
	}

}
