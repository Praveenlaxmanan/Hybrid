package com.sync;

public class two extends Thread{

	one on;
	String name2;
	
	two(one on, String name2){
		
		this.on = on;
		this.name2 = name2;
		
	}
	
	public void run(){
		
		try {
			
			on.testone(name2);
		
		} catch (InterruptedException e) {

		
		}
		
		
	}
	
	
}