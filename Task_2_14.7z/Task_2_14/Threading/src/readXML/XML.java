package readXML;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XML {

	public static File Filepath = new File("ReadXML//input.xml");
	
	public static void readXMLFile(){
		
		try{
		DocumentBuilderFactory DBuildFact = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = DBuildFact.newDocumentBuilder();
		Document doc = dBuilder.parse(Filepath);
		doc.getDocumentElement().normalize();
		System.out.println("Root Element value is: "+doc.getDocumentElement().getNodeName());
		NodeList nList = doc.getElementsByTagName("student");
		
		for(int i=0; i < nList.getLength(); i++){
			
			Node nodeName = nList.item(i);
			System.out.println("Current Element: "+nodeName.getNodeName());
			if(nodeName.getNodeType() == nodeName.ELEMENT_NODE){
				
				Element element = (Element) nodeName;
				System.out.println("Student RollNo: "+element.getAttribute("rollno"));
				
				
				System.out.println("FirstName: "+element.getElementsByTagName("firstname").item(0).getTextContent());
				System.out.println("LastName: "+element.getElementsByTagName("lastname").item(0).getTextContent());
				System.out.println("Nickname: "+element.getElementsByTagName("nickname").item(0).getTextContent());
				System.out.println("Marks: "+element.getElementsByTagName("marks").item(0).getTextContent());
				System.out.println();
				
				
			}
			
		}
		
		
		
		}catch(Exception e){
			
			System.out.println("XML file is not readable");
			e.printStackTrace();
			
		}
		
	}
	
	
	public static String Converts(int i){
		
		return i > 0 && i < 27 ? String.valueOf((char)(i + 64)) : null;
		
	}
	
	public static void main(String[] args) {
		

		readXMLFile();
		
		
	}

	
}
