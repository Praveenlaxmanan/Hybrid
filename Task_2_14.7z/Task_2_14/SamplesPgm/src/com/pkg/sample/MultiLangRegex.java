package com.pkg.sample;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MultiLangRegex {
	
	
	public static void regexText(){
		
		
		String xpathValue = "xpath#//a[@title='Billing']";
		
		Pattern pattern = Pattern.compile("'(.*)'");
		Matcher matcher = pattern.matcher(xpathValue);
		
		while(matcher.find()){
			
			System.out.println(matcher.group(1));
			String engLan = matcher.group(1);
			String frenchLan = "French";
			String replacedVal = xpathValue.replaceAll(engLan, frenchLan);
			System.out.println("replacedVal :"+replacedVal);
			
		}
		
		
		ReadExcel excel = new ReadExcel("C:/Users/prav2435.PLINTRON.000/Desktop/MultiLanguage.xls");
		
		int rowCountVal = excel.getRowCount("Language");
		
		for(int i = 1; i < rowCountVal; i++){
		
		String englishValue = excel.getCellData("Language", "ENGLISH", i);
		
		if(englishValue.equalsIgnoreCase("Billing")){
			
			System.out.println("englishValue :"+englishValue);
			
			String frenchValue = excel.getCellData("Language", "FRENCH", i);
			
			System.out.println("frenchValue :"+frenchValue);
			
			
		}
		
		
		}
		
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		
		
		regexText();
		
	}

}
