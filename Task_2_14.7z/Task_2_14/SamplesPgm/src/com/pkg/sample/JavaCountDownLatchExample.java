package com.pkg.sample;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class JavaCountDownLatchExample {
	
	
	public static void main(String[] args) {
		
		
		final CountDownLatch latch = new CountDownLatch(3);
		
		
		Thread serviceOneThread = new Thread(new ServiceOne(latch));
		Thread serviceTwoThread = new Thread(new ServiceTwo(latch));
		
		serviceOneThread.start();
		
		serviceTwoThread.start();
		
		try{
			
			//latch.await(10, TimeUnit.SECONDS);
			latch.await();
			System.out.println("Starting main Thread");
			
		}catch(Exception e){
			
			
			e.printStackTrace();
			
			
		}
		
//		serviceTwoThread.start();
		
	}
	
		
}
