package com.pkg.sample;

import java.util.concurrent.CountDownLatch;

public class ServiceOne implements Runnable {

	private final CountDownLatch latch;
	
	public ServiceOne(CountDownLatch latch){
		
		this.latch = latch;
		
	}

	@Override
	public void run() {
		
		System.out.println("Started Service One");
		latch.countDown();
	}
	
}
