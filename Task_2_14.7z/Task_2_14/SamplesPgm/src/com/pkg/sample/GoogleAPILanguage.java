package com.pkg.sample;

import com.google.api.GoogleAPI;
import com.google.api.translate.Language;
import com.google.api.translate.Translate;

public class GoogleAPILanguage {
	
	
	public static void langaugeTranslate() throws Exception{
		
		
		GoogleAPI.setHttpReferrer("http://code.google.com/p/google-api-translate-java/");
        GoogleAPI.setKey("AIzaSyBi7y4EgC0B-Q9UZg-tOzsOI0sLQ8F1Oow");
		
		String transText = Translate.execute("Hello, how are you?", Language.ENGLISH, Language.FRENCH);
		
		System.out.println("transText :"+transText);
		
	}

	
	public static void main(String[] args) throws Exception {
		
		
		langaugeTranslate();
	}
	
}
