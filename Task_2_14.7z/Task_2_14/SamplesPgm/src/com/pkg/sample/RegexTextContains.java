package com.pkg.sample;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexTextContains {
	
	
	public static void containsText(){
		
		
		String text = "xpath#.//*[@id='bundleSMS']//th[contains(text(),'Zone 1')]/../th[2]";
		
		Pattern pattern = Pattern.compile("(.*)contains(.*)text(.*),'(.*)'");
		
		Matcher matcher = pattern.matcher(text);
		
		while(matcher.find()){
		
		
			System.out.println("Matcher :" +matcher.group(4));
		
		}
			
	}
	
	
	public static void main(String[] args) {
		
		containsText();
		
	}

}