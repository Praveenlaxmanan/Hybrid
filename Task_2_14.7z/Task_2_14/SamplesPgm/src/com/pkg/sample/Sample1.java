package com.pkg.sample;

public class Sample1 {

	
	public static void loop1(){
		
		
		for(int i = 1; i < 6; i++){
			
			for(int j = 0; j < i; j++){
				
				System.out.print(j+1);
				
			}
			
			System.out.println("");
			
			
		}
		
	}
	
	
	public static void loop2(){
		
		
		for(int i = 1; i < 6; i++){
			
			
			for(int j = 0; j < i; j++){
				
				
				System.out.print(i);
				
			}

				System.out.println("");
			
		}
		
		
	}

	
	public static void main(String[] args) {
		
//	loop1();	
	loop2();
		
		
	}
	
	
	
}
