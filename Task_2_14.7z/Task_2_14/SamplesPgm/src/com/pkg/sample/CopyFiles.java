package com.pkg.sample;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.google.common.io.Files;

public class CopyFiles {
	
	
	public static void moveFiles(String existFileName) throws IOException{
		
		File fromDir = new File("CurrentDir/");
		File toDir = new File("ReplaceDir/");
		
		if(fromDir.length() == 0){
			
			
			System.out.println("Files are not available");
			
		}
		
		System.out.println("Files are available");
		
		for(File listOfFiles : fromDir.listFiles()){
			
			if(listOfFiles.getName().equals(existFileName)){
				
				Files.copy(fromDir, toDir);
				
			}
			
		}
		
	}
	
	
	public static void main(String[] args) throws IOException {
		
		
//		moveFiles("CRMService.log");
		
		stepTwo("CRMService");
		
	}
	
	
	
	public static void dateFormat(){
		
		
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MMM.yyyy-hh_mm_ss");
		
		System.out.println(dateFormat.format(date));
		
		
	}
	
	
	public static void stepTwo(String existFileName){
		
		InputStream inStream = null;
		OutputStream outStream = null;
		
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MMM.yyyy-hh_mm_ss");
		
		String todayDate = dateFormat.format(date);
		
		try{
			
			File aFile = new File("CurrentDir/"+existFileName+".log");
			File bFile = new File("ReplaceDir/"+todayDate+".log");
			
			inStream = new FileInputStream(aFile);
			outStream = new FileOutputStream(bFile);
			
			if(aFile.length() != 0){
			
			System.out.println("File is available");
			
			byte[] buffer = new byte[10240];
			
			int length;
			
			//Copy the file
			
			System.out.println("Going to replace the files");
			
			while((length = inStream.read(buffer)) > 0){
				
				outStream.write(buffer, 0, length);
				
			}
			
				inStream.close();
				outStream.close();
				
				System.out.println("File is copied Successfully");
				
				
			}else{
				
				
				System.out.println("File is not available");
				
			}
			
		}catch(FileNotFoundException e){
			
			System.out.println("File is not available");
			
			
		}catch(Exception e){
			
			e.printStackTrace();
			
		}
		
		
	}
	

}
