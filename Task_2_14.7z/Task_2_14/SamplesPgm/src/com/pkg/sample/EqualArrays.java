package com.pkg.sample;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class EqualArrays {
	
	public static int[] allValues={1,2,3,4,5,6,7,8};
	
	public static int[] equalArr(int[] a, int removeAct){
		
		
		int reorderInd = a.length - 1;
		
		for(int i = removeAct; i < reorderInd; i++){
			
			allValues[i]= allValues[i+1];
			
		}
			
			int[] convertedValues = Arrays.copyOf(allValues, reorderInd);
			
			
			for(int j = 0; j<convertedValues.length; j++){
				
				System.out.println("appComponentEventstemp :" +convertedValues[j]);
				
			}
			
			
			return convertedValues;
			
	}
	
	
	
	public static void arrayLst(){
		
		
		ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
		  list.add("Test1");//Adding object in arraylist  
		  list.add("Test2");  
		  list.add("Test3");  
		  list.add("Test4");  
		  
		  //Traversing list through Iterator  
		  Iterator itr=list.iterator();  
		  
		  while(itr.hasNext()){  
		   System.out.println(itr.next());  
		  }  
		
	}
	
	public static void main(String[] args) {
		
		
//		equalArr(new int[] {1,2,3,4,5,6,7,8}, 1);
		
		arrayLst();
		
	}
	
	
	

}
