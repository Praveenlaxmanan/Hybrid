package com.pkg.sample;

public class NonStatic1 {
	
	
	public void nonStaticOne(){
		
		
		System.out.println("Non Static One");
		
	}

}
