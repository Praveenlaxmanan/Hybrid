package com.pkg.sample;

public class StackTraceElementDemo {

   public static void main(String[] args) {

   function1();
   }
 
   public static void function1()
   {
   new StackTraceElementDemo().function2();
   }


 
   public void function2() 
   {
   int i;
   System.out.println("method name : ");

   // print stack trace
   for( i = 1; i <= 3; i++ ) {
	   
   System.out.println(Thread.currentThread().getStackTrace()[2].getMethodName());
   
   			}
   }
   
	}   



