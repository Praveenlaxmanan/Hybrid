package com.pkg.sample;

import java.util.concurrent.CountDownLatch;

public class ServiceTwo implements Runnable {

	private final CountDownLatch latch;
	
	public ServiceTwo(CountDownLatch latch){
		
		this.latch = latch;
		
	}

	@Override
	public void run() {
		
		System.out.println("Started Service Two");
		latch.countDown();
	}
	
	
	
	
}
