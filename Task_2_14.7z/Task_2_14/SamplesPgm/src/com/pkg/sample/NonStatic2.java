package com.pkg.sample;

public class NonStatic2 {
	
	
	public void nonStaticTwo(){
		
		
		System.out.println("Non Static Two");
		
		
		NonStatic1 one = new NonStatic1();
		one.nonStaticOne();
		
		
	}
	
	
	public static void main(String[] args) {
		
		
		NonStatic2 two = new NonStatic2();
		two.nonStaticTwo();
		
	}
	
	
}
