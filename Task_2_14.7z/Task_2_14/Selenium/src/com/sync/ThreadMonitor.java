package com.sync;

import java.io.IOException;

public class ThreadMonitor extends Thread {
	
	public void run(){
		
		while(true){
			
			System.out.println("Thread is Montoring");
			try {
				Runtime.getRuntime().exec("input//close.exe");
				
			} catch (IOException e1) {
				
				e1.printStackTrace();
			}
			
			try{
				
				Thread.sleep(2000);
				
			}catch(Exception e){
				
				e.printStackTrace();
				
			}
			
		}
		
	}

}
