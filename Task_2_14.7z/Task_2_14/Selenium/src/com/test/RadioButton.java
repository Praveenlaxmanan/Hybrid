package com.test;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class RadioButton {

	public static WebDriver driver;


	public static void Check() throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.110.157:1503/Login/POSLogin.aspx");
		driver.findElement(By.id("UserName")).sendKeys("CPOS_WT_RET1");
		driver.findElement(By.id("Password")).sendKeys("12");
		driver.findElement(By.id("LoginButton")).click();
		driver.findElement(By.id("lnkMenu_23")).click();
		driver.findElement(By.xpath("//*[@id='ctl00_ContentPlaceHolder1_divSubMenuList']/div[1]/div[1]/a/span")).click();
		
		WebElement transfer = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlDemination"));
		Select tra = new Select(transfer);
		tra.selectByVisibleText("Balance Transfer");
		
		Thread.sleep(2000);
		
		List<WebElement> radio = driver.findElements(By.xpath("//table[@id='ctl00_ContentPlaceHolder1_rblIncentiveConfiguration']/tbody/tr/td"));
		
		System.out.println("Size :" +radio.size());
		
		for(WebElement s : radio){
		
		System.out.println("I value :"+s.getText());

		if(s.getText().equalsIgnoreCase("yes")){
			
			s.click();
			
			System.out.println("Success");
			
			}
		
		}
	}
		

	public static void main(String[] args) throws InterruptedException {
		
		Check();
		
	}
		
	
	
}
