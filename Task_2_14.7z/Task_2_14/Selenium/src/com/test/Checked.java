package com.test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

public class Checked {

public static WebDriver driver;


public static void Check() throws InterruptedException, IOException{
	
	System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.manage().window().maximize();
	driver.get("http://192.168.110.157:1503/Login/POSLogin.aspx");
	driver.findElement(By.id("UserName")).sendKeys("CPOS_REG_RET1");
	driver.findElement(By.id("Password")).sendKeys("12");
	driver.findElement(By.id("LoginButton")).click();
	driver.findElement(By.id("lnkMenu_22")).click();
	driver.findElement(By.xpath("//*[@id='ctl00_ContentPlaceHolder1_divSubMenuList']/div[4]/div[1]/a/span")).click();
	
	Runtime.getRuntime().exec("input//Test.exe");
	
	driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtMobileNo")).sendKeys("19912510023");
	
	Runtime.getRuntime().exec("input//close.exe");
	
	/*driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtPukCode")).sendKeys("08100002");
	WebElement ques = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlSecQuestion"));
	Select se = new Select(ques);
	se.selectByVisibleText("Why?");
	driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtAnswer")).sendKeys("Me");
	WebElement title = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlTitle"));
	Select ti = new Select(title);
	ti.selectByVisibleText("Mr");
	driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtFName")).sendKeys("Automation");
	driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtLname")).sendKeys("test");
	
	WebElement day = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlDay1"));
	Select dayy = new Select(day);
	dayy.selectByVisibleText("01");
	WebElement mon = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlMonth1"));
	Select month = new Select(mon);
	month.selectByVisibleText("01");
	WebElement yer = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlYear1"));
	Select year = new Select(yer);
	year.selectByVisibleText("1988");
	driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtEmail")).sendKeys("automation.test@plintron.com");
	driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtEMailIDConfirm")).sendKeys("automation.test@plintron.com");
	driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtAltNo")).sendKeys("1234567890");
	driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtZipCode")).sendKeys("20910");
	driver.findElement(By.id("ctl00_ContentPlaceHolder1_btnFindAddress")).click();
	Thread.sleep(8000);
	driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtHouseNum")).sendKeys("12");
	driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtStreet")).sendKeys("Street");
	WebElement hear = driver.findElement(By.id("ctl00_ContentPlaceHolder1_lstHearUs"));
	Select hearus = new Select(hear);
	hearus.selectByVisibleText("News Paper");
	WebElement coun = driver.findElement(By.id("ctl00_ContentPlaceHolder1_lstCallCountry"));
	Select country = new Select(coun);
	country.selectByVisibleText("Afghanistan");
	WebElement lan = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlLanguage"));
	Select lang = new Select(lan);
	lang.selectByVisibleText("ENGLISH");
	WebElement x = driver.findElement(By.id("ctl00_ContentPlaceHolder1_chkAgreeTerms"));
	x.click();
	driver.findElement(By.id("ctl00_ContentPlaceHolder1_btnReset")).click();
	Thread.sleep(4000);
	
	String checks = x.getText();
	System.out.println("GetText ::"+checks);
	
	String value = x.getAttribute("value");
	System.out.println("Value ::"+value);*/
	
	
	driver.findElement(By.id("ctl00_ContentPlaceHolder1_chkMarkSMS")).click();
	
	String checkstatus = driver.findElement(By.id("ctl00_ContentPlaceHolder1_chkMarkSMS")).getAttribute("checked");
	
	System.out.println("Checkstatus :" +checkstatus);
	
	//driver.quit();
	
	
}


public static void readXL() throws IOException{
	
	//File path
	String fileName = "input/test.xlsx";
	InputStream  XlsxFileToRead = new FileInputStream(fileName);
	XSSFWorkbook workbook = new XSSFWorkbook(XlsxFileToRead);
	XSSFSheet sheet = workbook.getSheet("Sheet1");
	XSSFCell cell;
	cell = sheet.getRow(0).getCell(0);
	String Username = cell.getStringCellValue();
	System.out.println("Values :"+Username);
	
}
	

public static void main(String[] args) throws InterruptedException, IOException {
	
//	Check();
	readXL();
	
}
	


}
