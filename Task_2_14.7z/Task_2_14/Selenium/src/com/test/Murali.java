package com.test;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Murali {
	
	public static void pageTest(){
		
		
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.110.157:1503/Login/POSLogin.aspx");
		driver.findElement(By.id("UserName")).sendKeys("CPOS_WT_RET1");
		driver.findElement(By.id("Password")).sendKeys("12");
		driver.findElement(By.id("LoginButton")).click();
		driver.findElement(By.id("lnkMenu_23")).click();
		driver.findElement(By.xpath(".//*[@id='ctl00_ContentPlaceHolder1_divSubMenuList']/div[1]/div[2]/a/span")).click();
		
		
		String ColumnNamePrimary="StaffMode";
		
		String webtableid="ctl00_ContentPlaceHolder1_grdChild";
		
		WebElement webtable=driver.findElement(By.id(webtableid));
		//String WebTableID=webtable.getAttribute("id");
		
		int foundColumnNumber = 0;
		
		List<WebElement> headerColumns=webtable.findElements(By.xpath("//*[@id='ctl00_ContentPlaceHolder1_grdChild']/tbody/tr/th"));
		
		int headerCounter=0;
		
		for (WebElement temp : headerColumns) {
			String GetTitleHeaders=temp.getText();
			
			
			if (GetTitleHeaders.equalsIgnoreCase(ColumnNamePrimary)){
				foundColumnNumber=headerCounter+1;
			}
			
			headerCounter=headerCounter+1;
			
			}
		
		System.out.println("No :" +foundColumnNumber);
		
		
	}
	
	public static void main(String[] args) {
		
		pageTest();
		
	}
	
	
	

}
