package com.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SDate {
	
	
	public static void dateFormat(String oldFormat, String newFormat) throws ParseException{
		
		String getText = "13/05/2016";
		
		SimpleDateFormat dFormat = new SimpleDateFormat(oldFormat);
		
		Date d = dFormat.parse(getText);
		
		dFormat.applyPattern(newFormat);
		
		System.out.println(dFormat.format(d));
		
	}
	
	
	public static void main(String[] args) throws ParseException {
		
		dateFormat("dd/MM/yyyy", "MM/dd/yyyy");
		
	}
	

}
