package com.test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

public class AutoIT {

	public static WebDriver driver;
	
	public static void Check() throws InterruptedException, IOException{
		
		try{
		
		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
		caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
		System.setProperty("webdriver.ie.driver", "input//IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
//		Runtime.getRuntime().exec("input//notepad_demo.exe");
		driver.get("http://192.168.110.157:1503/Login/POSLogin.aspx");
		driver.findElement(By.id("UserName")).sendKeys("CPOS_REG_RET1");
		driver.findElement(By.id("Password")).sendKeys("12");
		driver.findElement(By.id("LoginButton")).click();
		driver.findElement(By.id("lnkMenu_22")).click();
		driver.findElement(By.xpath("//*[@id='ctl00_ContentPlaceHolder1_divSubMenuList']/div[4]/div[1]/a/span")).click();
		
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtMobileNo")).sendKeys("19912510023");
		
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtPukCode")).sendKeys("08100002");
		
		WebElement ques = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlSecQuestion"));
		Select se = new Select(ques);
		se.selectByVisibleText("Why?");
		
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtAnswer")).sendKeys("Me");
		
		WebElement title = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlTitle"));
		Select ti = new Select(title);
		ti.selectByVisibleText("Mr");
		
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtFName")).sendKeys("Automation");
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtLname")).sendKeys("test");
		
		WebElement day = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlDay1"));
		Select dayy = new Select(day);
		dayy.selectByVisibleText("31");
		
		WebElement mon = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlMonth1"));
		Select month = new Select(mon);
		month.selectByVisibleText("02");
		
		WebElement yer = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlYear1"));
		Select year = new Select(yer);
		year.selectByVisibleText("1988");
		
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtEmail")).sendKeys("automation.test@plintron.com");
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtEMailIDConfirm")).sendKeys("automation.test@plintron.com");
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtAltNo")).sendKeys("1234567890");
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtZipCode")).sendKeys("20910");
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_btnFindAddress")).click();
		Thread.sleep(4000);
		
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtHouseNum")).sendKeys("12");
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtStreet")).sendKeys("Street");
		
		WebElement hear = driver.findElement(By.id("ctl00_ContentPlaceHolder1_lstHearUs"));
		Select hearus = new Select(hear);
		hearus.selectByVisibleText("News Paper");
		
		WebElement coun = driver.findElement(By.id("ctl00_ContentPlaceHolder1_lstCallCountry"));
		Select country = new Select(coun);
		country.selectByVisibleText("Afghanistan");
		
		WebElement lan = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlLanguage"));
		Select lang = new Select(lan);
		lang.selectByVisibleText("ENGLISH");
		
		WebElement x = driver.findElement(By.id("ctl00_ContentPlaceHolder1_chkAgreeTerms"));
		x.click();
		
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_btnSubmit")).click();
		
		WebElement error = driver.findElement(By.id("ctl00_ContentPlaceHolder1_lblError"));
		
		System.out.println(error.getText());
		
		driver.findElement(By.id("lnkMenu_22")).click();
		driver.findElement(By.xpath("//*[@id='ctl00_ContentPlaceHolder1_divSubMenuList']/div[4]/div[1]/a/span")).click();
		
		driver.quit();
		
		//Runtime.getRuntime().exec("input//close.exe");
		
		}catch(StaleElementReferenceException e){
			
			e.printStackTrace();
			
		}
		
	}
	
	public static void main(String[] args) throws InterruptedException, IOException {
		
		Check();
	}
	
}
