package com.test;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Correspondant {
	
	public static WebDriver driver;
	
	public static void corresValues(){
		
//		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
//		caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
//		Runtime.getRuntime().exec("input//notepad_demo.exe");
		
		driver.get("file:///D:/codes/tableValues/Manage%20Staff.html");
		
		driver.findElement(By.id("UserName")).sendKeys("CPOS_WT_RET1");
		driver.findElement(By.id("Password")).sendKeys("12");
		driver.findElement(By.id("LoginButton")).click();
		driver.findElement(By.id("lnkMenu_23")).click();
		driver.findElement(By.xpath("//span[text()='Manage Child']")).click();
		
		List<WebElement> row_size = driver.findElements(By.xpath("//*[@id='ctl00_ContentPlaceHolder1_grdChild']/tbody/tr/td"));
		
		/*System.out.println("Row_size :"+row_size.size());
		
		String xpath_1 = ".//*[@id='ctl00_ContentPlaceHolder1_grdChild']/tbody/tr[";
		
		String xpath_2 = "]/td[2";
		
		String xpath_3 = "]";
		
		String whole = xpath_1+xpath_2+xpath_3;
		
		System.out.println(whole);*/
		
		//No of rows
		
			
			for(int i = 2; i <= row_size.size(); i++){
				
				
				/*String whole_Xpath = xpath_1+i+xpath_2+xpath_3;
				
				String table = driver.findElement(By.xpath(whole_Xpath)).getText();
				
				System.out.println(table + " ");*/
				
				String table = driver.findElement(By.xpath("//table[@id='ctl00_ContentPlaceHolder1_grdChild']/tbody/tr["+i+"]/td[2]")).getText();
				
				System.out.println(table + " ");
				
			}
			
			
		driver.quit();
		
		
		
		
	}
	
	public static void main(String[] args) {
		
		corresValues();
	}
	

}
