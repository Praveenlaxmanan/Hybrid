package com.test;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UpdateTableValues {
	
	public static void update() throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.110.157:1503/Login/POSLogin.aspx");
		driver.findElement(By.id("UserName")).sendKeys("CPOS_WT_RET1");
		driver.findElement(By.id("Password")).sendKeys("12");
		driver.findElement(By.id("LoginButton")).click();
		driver.findElement(By.id("lnkMenu_23")).click();
		driver.findElement(By.xpath(".//*[@id='ctl00_ContentPlaceHolder1_divSubMenuList']/div[1]/div[2]/a/span")).click();
		
		//Initialized the variables as dummy
		int breakLoop = 0;
		String primaryColumnName = null;
		String secColumnName = null;
		String expectedRowValue = null;
		String expectedTextFromTable = null;
		String attributeID = null;
		
		// Get the values from excel sheet to find the rows and columns from web table
		primaryColumnName = "Staff name";
		secColumnName = "MSISDN";
		expectedRowValue = "BTSTAFFAUTO";
		expectedTextFromTable = "*********0066";
		
		//Get the ID from xpath(whole web table) 
		attributeID = driver.findElement(By.xpath(".//*[@id='ctl00_ContentPlaceHolder1_grdChild']")).getAttribute("id");
		System.out.println("attributeID :" +attributeID);
		
		// To find the pagination value to get the last row value for clicking on pagination
		List<WebElement> paginationRowValue = driver.findElements(By.xpath("//*[@id='"+attributeID+"']/tbody/tr"));
		int pageRowValue = paginationRowValue.size();
		System.out.println("pageRowValue :"+pageRowValue);
		
		
		
		List<WebElement> headerColumns = driver.findElements(By.xpath("//*[@id='"+attributeID+"']/tbody/tr/th"));
		
		int findPrimaryColumn = 0;
		int findcolumnToValidate = 0;
		
		int headerCounterPrimaryColumn = 0;
		int headerCounterColumnValidate = 0;
		
		
		//To find the primary column count value from webTable
		for(WebElement temp : headerColumns){
			
			String GetTitleHeaders = temp.getText();
			
			if (GetTitleHeaders.equalsIgnoreCase(primaryColumnName)){
				findPrimaryColumn = headerCounterPrimaryColumn + 1;
				break;
			}
			
			headerCounterPrimaryColumn = headerCounterPrimaryColumn + 1;
		}
		
		System.out.println("foundColumnPrimary :" +findPrimaryColumn);
		
		
		//To find the secondary column count value from webTable
		for (WebElement temp : headerColumns) {
			String GetTitleHeaders=temp.getText();
			
			
			if (GetTitleHeaders.equalsIgnoreCase(secColumnName)){
				findcolumnToValidate = headerCounterColumnValidate + 1;
				break;
			}
			
			headerCounterColumnValidate = headerCounterColumnValidate + 1;
			
			}
		
		System.out.println("foundColumnNumber :" +findcolumnToValidate);
		
		
		//To get the size for pagination button in web table, to check how many paginations are available in web table
		List<WebElement> pagination = driver.findElements(By.xpath("//*[@id='"+attributeID+"']/tbody/tr["+pageRowValue+"]/td/table/tbody/tr/td"));
		System.out.println("Pagination size :"+pagination.size());
		
		//To check the pagination size
		if(pagination.size() > 1){
			
			
			for(int i = 1; i <= pagination.size(); i++){
				
				
				//If more than one page in web table, then clicking on pagination and find the element
				if(i != 1){
					
					System.out.println("Clicking on pagination :"+i);
					
					driver.findElement(By.xpath("//*[@id='"+attributeID+"']/tbody/tr["+pageRowValue+"]/td/table/tbody/tr/td["+i+"]/a")).click();
					Thread.sleep(3000);
					System.out.println("Moving to next page");
				}
				
				//To find the row size and iterate the all column and row values in web table
				List<WebElement> rows = driver.findElements(By.xpath("//*[@id='"+attributeID+"']/tbody/tr"));
				System.out.println("No of rows in current page :"+rows.size());
				
				//Iterate the rows
				
				for(int noOfRows = 2; noOfRows < rows.size(); noOfRows++){
					
					String columnValue = driver.findElement(By.xpath("//*[@id='"+attributeID+"']/tbody/tr["+noOfRows+"]/td["+findPrimaryColumn+"]")).getText();
					System.out.println("ColumnValue :"+columnValue);
					
					if(columnValue.equalsIgnoreCase(expectedRowValue)){
						
						System.out.println("Value available in table");
						
						String getExpectedValueFromTable = driver.findElement(By.xpath("//table[@id='"+attributeID+"']/tbody/tr["+noOfRows+"]/td["+findcolumnToValidate+"]/span")).getText();
						
						System.out.println("Correspondant value is :"+getExpectedValueFromTable);
						
						if(getExpectedValueFromTable.equalsIgnoreCase(expectedTextFromTable)){
							
							System.out.println("Expected value matches with actual value in table");
							
							System.out.println(getExpectedValueFromTable +" = " +expectedTextFromTable );
							
							breakLoop = 1;
							
							break;
							
							
						}else {
							
							System.out.println("Expected value not matches with actual value in table");
							breakLoop = 1;
							break;
							
						}
						
						
					}
					
				}
				
				if(breakLoop == 1){
					
					System.out.println("Break the condition");
					break;
					
				}
				
			}
			
		}else {
			
			
			List<WebElement> rows = driver.findElements(By.xpath("//*[@id='ctl00_ContentPlaceHolder1_grdChild']/tbody/tr"));
			System.out.println("No of rows in current page :"+rows.size());
			
			for(int noOfRows = 2; noOfRows < rows.size(); noOfRows++){
				
				String columnValue = driver.findElement(By.xpath("//*[@id='ctl00_ContentPlaceHolder1_grdChild']/tbody/tr["+noOfRows+"]/td[2]")).getText();
				System.out.println("ColumnValue :"+columnValue);
				
				if(columnValue.equalsIgnoreCase(expectedRowValue)){
					
					System.out.println("Value available in table");
					
					String getExpectedValueFromTable = driver.findElement(By.xpath("//table[@id='ctl00_ContentPlaceHolder1_grdChild']/tbody/tr["+noOfRows+"]/td[4]/span")).getText();
					
					System.out.println("Correspondant value is :"+getExpectedValueFromTable);
					
					if(getExpectedValueFromTable.equalsIgnoreCase(expectedTextFromTable)){
						
						System.out.println("Expected value matches with actual value in table");
						
						System.out.println(getExpectedValueFromTable +" = " +expectedTextFromTable );
						
						break;
						
						
					}else {
						
						System.out.println("Expected value not matches with actual value in table");
						
						break;
						
					}
					
					
				}
				
			}
			
		}
		
		
		
		driver.quit();
		
	}
	
	public static void testChecks(){
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://datatables.net/examples/basic_init/alt_pagination.html");
		
		WebElement text = driver.findElement(By.xpath(".//*[@id='example']/tbody/tr[7]/td[1]"));
		
		String expectedText = "Zorita Serrano";
		
		if(text.getText().equalsIgnoreCase(expectedText)){
			
			System.out.println("Element is found in web table");
			
		}else {
			
			List<WebElement> pagination = driver.findElements(By.xpath("//*[@id='example_paginate']/span/a"));
			
			for(int i = 1; i<=pagination.size(); i++){

				WebElement paginationClick = driver.findElement(By.xpath("//*[@id='example_paginate']/span/a["+i+"]"));
				
				paginationClick.click();
				
				text = driver.findElement(By.xpath(".//*[@id='example']/tbody/tr[7]/td[1]"));
				
				if(text.getText().equalsIgnoreCase(expectedText)){
					
					System.out.println("Text is found, while doing pagination :"+expectedText);
					
					
				}
				
			}
			
		}
		
		driver.quit();
		
	}
	
	
	public static void xpathPagination() throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.110.157:1503/Login/POSLogin.aspx");
		driver.findElement(By.id("UserName")).sendKeys("CPOS_WT_RET1");
		driver.findElement(By.id("Password")).sendKeys("12");
		driver.findElement(By.id("LoginButton")).click();
		driver.findElement(By.id("lnkMenu_23")).click();
		driver.findElement(By.xpath(".//*[@id='ctl00_ContentPlaceHolder1_divSubMenuList']/div[1]/div[2]/a/span")).click();
		
		String strData="WTSTAFF1";
		
		String expectedValue="*********0014";

	
		List<WebElement> pagination = driver.findElements(By.xpath("//*[@id='ctl00_ContentPlaceHolder1_grdChild']/tbody/tr"));
		
		System.out.println("Size :" +pagination.size());

		if(pagination.size() > 1){

			for(int i = 1 ; i<=pagination.size() ;i++ ){

				//Skip the first Page since it is available on the screen
				if(i!=1){
					
				System.out.println("Clicking page Number : "+i);
				driver.findElement(By.xpath("//*[@id='ctl00_ContentPlaceHolder1_grdChild']/tbody/tr[7]/td/table/tbody/tr/td["+i+"]/a")).click();
				Thread.sleep(3000);
				System.out.println("Moving to Next page");

				}
				
				List<WebElement> rows = driver.findElements(By.xpath("//table[@id='ctl00_ContentPlaceHolder1_grdChild']/tbody/tr"));
				System.out.println("Total Number of Rows in the Current Page : "+rows.size());
				System.out.println("Skipping the first Row(Header) and the Last row(Pagination) in row loop");
				
				//Iterate to all rows in the webtable in the current page
				for(int rNum=2 ;rNum < rows.size() ;rNum++){

					String colValue = driver.findElement(By.xpath("//table[@id='ctl00_ContentPlaceHolder1_grdChild']/tbody/tr["+rNum+"]/td[2]")).getText();
					System.out.println("Col value is : "+colValue);

					//If teh col value is found
					if(colValue.equalsIgnoreCase(strData)){

						System.out.println("Value found in the Table...");
						String value = driver.findElement(By.xpath("//table[@id='ctl00_ContentPlaceHolder1_grdChild']/tbody/tr["+rNum+"]/td[4]/span")).getText();
						System.out.println("Corresponding value is : " +value);
						
						if(value.trim().equals(expectedValue)){
							System.out.println("Expected value Matches with the Actual value from the table. Case Passed!");
							System.out.println("Breaking the Row loop");
							break;

						}else{
							
							System.out.println("Expected value does not matches with the Actual value from the table. Case Failed!");
							System.out.println("Breaking the Row loop");
							break;
						}

					}

				}
				
				System.out.println("Got all Elements in the "+i+"th Page");
			}

		}

		
	driver.quit();	
		
	}
	
		
		
		
	public static void main(String[] args) throws InterruptedException {
		
		update();
//		testChecks();
//		xpathPagination();
		
	}
	

}
