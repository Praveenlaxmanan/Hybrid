package com.plintron.crm;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

public class Scrolls {
	
	public static WebDriver driver;
	public static void scrollOnPage() throws InterruptedException{
		
		File fileBrowser = new File("input//IEDriverServer.exe");
		System.setProperty("webdriver.ie.driver", fileBrowser.getAbsolutePath());
		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
		caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		WebDriver driver = new InternetExplorerDriver(caps);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:6552/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		Thread.sleep(7000);
		
		/*String execScroll = "return document.documentElement.scrollHeight>document.documentElement.clientHeight;";
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Boolean isCheck = (Boolean) js.executeScript(execScroll);
		
		System.out.println(isCheck);
		
		if(isCheck.equals(true)){
			
			System.out.println("Scroll option is available in page");
			
			
		}else{
			
			System.out.println("Scroll option is not available in page");
			
		}*/
		
		Object rr = ((JavascriptExecutor) driver).executeScript("return document.documentElement.clientHeight");
		
		System.out.println(rr);
		
		
		driver.quit();
		
	}
	
	public static void scrollCheckSpecificElement() throws InterruptedException{
		
		File fileBrowser = new File("input//IEDriverServer.exe");
		System.setProperty("webdriver.ie.driver", fileBrowser.getAbsolutePath());
		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
		caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		WebDriver driver = new InternetExplorerDriver(caps);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:6552/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		Thread.sleep(5000);
		
		List<WebElement> scrollBar = driver.findElements(By.xpath("//div[@class='slimScrollBar']"));
		
		if(scrollBar.size() != 0){
		//	scrollVar="YES"
			WebElement checkElement = driver.findElement(By.xpath("//a[text()='OBA Additional Credit']/ancestor::tr//a[@class='item-link ng-binding']"));
			
			Coordinates cor = ((Locatable)checkElement).getCoordinates();
			cor.onPage();
			cor.inViewPort();
			String expValue = checkElement.getText();
			System.out.println("expValue :"+expValue);
			
			
		}else {
			
			WebElement checkElement = driver.findElement(By.xpath("//a[text()='OBA Additional Credit']/ancestor::tr//a[@class='item-link ng-binding']"));
			String expValue = checkElement.getText();
			System.out.println("expValue Else:"+expValue);
			
		}
		
		
		driver.quit();
		
	}
	
	
	public static void mouseHover() throws InterruptedException{
		
		System.setProperty("webdriver.ie.driver", "input//IEDriverServer.exe");
		
		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
        caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
        WebDriver driver = new InternetExplorerDriver(caps);
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:6552/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		Thread.sleep(5000);
		
		WebElement dropdown = driver.findElement(By.id("loadType"));
		Select se = new Select(dropdown);
		se.selectByVisibleText("MSISDN");
		
		driver.findElement(By.id("loadParameter")).sendKeys("(449)-94-400-400-1");
		driver.findElement(By.id("btnLoadSubscriber")).click();
		Thread.sleep(7000);
		
		
		WebElement attachment = driver.findElement(By.xpath("//span[text()='22657680']/ancestor::div[@class='ticket-header']/following-sibling::div//span[@title='Attachments']"));
		attachment.click();
		
	}
	
	
	public static void main(String[] args) throws InterruptedException {
		
//		scrollOnPage();
//		scrollCheckSpecificElement();
		mouseHover();
		
	}
	
	
}
