package com.plintron.crm;

import java.awt.AWTException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Working_on_CRM {
	
		// Script for validating the hidden content in webtable (CRM Ticketing Table)
	
		public static void main(String[] args) throws InterruptedException, AWTException{
	        // declaration and instantiation of objects/variables
	        WebDriver driver;	        
	        String baseUrl = "http://192.168.109.148:7656/";
	        
	        driver = new FirefoxDriver();	        
	        WebDriverWait wait = new WebDriverWait(driver,10); //you can play with the time integer  to wait for longer than 15 seconds.
	        
	        // launch IE and direct it to the Base URL
	        driver.get(baseUrl);
	        driver.manage().window().maximize();
	        
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("UserName"))); //if you want to wait for a particular title to show up
	        driver.findElement(By.id("UserName")).sendKeys("admin");
	        driver.findElement(By.id("Password")).sendKeys("123456");
	        driver.findElement(By.id("Login")).click();
	        
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='crmPage']/div[1]/div/div[2]/span[1]/span[2]")));
	        
	        new Select(driver.findElement(By.id("loadType"))).selectByVisibleText("MSISDN");	        
	        driver.findElement(By.id("loadParameter")).sendKeys("447871200324");	        
	        driver.findElement(By.id("btnLoadSubscriber")).click();
	        
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("liMSISDN")));
	        
	        WebElement table = driver.findElement(By.xpath(".//*[@id='tTicketingToolbody']"));	        
	        String table_id = table.getAttribute("id");	        
	        List<WebElement> allrows = table.findElements(By.xpath("//*[@id='"+ table_id +"']/div"));	        
	        System.out.println(allrows.size());	       
			
			for(int row=1; row<=allrows.size(); row++)
	    	{
				
				WebElement element= driver.findElement(By.xpath(".//*[@id='tTicketingToolbody']/div["+ row +"]/div[1]/div[1]/span[2]"));
				
				Coordinates coordinate = ((Locatable)element).getCoordinates(); 
				coordinate.onPage(); 
				coordinate.inViewPort();

				String ticketid = driver.findElement(By.xpath(".//*[@id='tTicketingToolbody']/div["+ row +"]/div[1]/div[1]/span[2]")).getText();

				String status = driver.findElement(By.xpath(".//*[@id='tTicketingToolbody']/div["+ row +"]/div[1]/div[2]/span[3]")).getText();

				String ticketraisedby = driver.findElement(By.xpath(".//*[@id='tTicketingToolbody']/div["+ row +"]/div[1]/div[4]/span")).getText();
				System.out.println(ticketid + "-" + status + "-" + ticketraisedby);
	    	
	    	}
	        

	        driver.findElement(By.id("dropdownMenu1")).click();
	        
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("logoutCRM")));
	        
	        driver.findElement(By.id("logoutCRM")).click();
	        
	        //close Internet Explorer
	        driver.quit();
	        
	        // exit the program explicitly
//	        System.exit(0);  */
	    }
	}


