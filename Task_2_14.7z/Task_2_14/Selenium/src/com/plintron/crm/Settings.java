package com.plintron.crm;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Settings {

	public static WebDriver driver;
	public static void getTableValuesByEntering() throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:7656/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("dropdownMenu1")).click();
		driver.findElement(By.id("settingsMenu")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("Configuration")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//*[@class='well well-sm brandConfigTile dropdown']//text()[normalize-space()='GBR']/following-sibling::div//span[@class='caret']")).click();
		
		List<WebElement> dropdownVal = driver.findElements(By.xpath("//*[@class='well well-sm brandConfigTile dropdown']//text()[normalize-space()='GBR']/following-sibling::div//ul[@class='dropdown-menu']/child::li"));
		
		for(WebElement s : dropdownVal){
			
			System.out.println(s.getText());
			
			if(s.getText().equalsIgnoreCase("LYCA")){
				
				s.click();
				
			}
			
		}
		
		Thread.sleep(2000);
		WebElement keysEnter = driver.findElement(By.id("gs_Key"));
		keysEnter.sendKeys("trDOB");
		keysEnter.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		driver.quit();
		
	}
	
	
	public static void getTableValuesByIterate() throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:7656/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("dropdownMenu1")).click();
		driver.findElement(By.id("settingsMenu")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("Configuration")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//*[@class='well well-sm brandConfigTile dropdown']//text()[normalize-space()='GBR']/following-sibling::div//span[@class='caret']")).click();
		
		List<WebElement> dropdownVal = driver.findElements(By.xpath("//*[@class='well well-sm brandConfigTile dropdown']//text()[normalize-space()='GBR']/following-sibling::div//ul[@class='dropdown-menu']/child::li"));
		
		for(WebElement s : dropdownVal){
			
			System.out.println(s.getText());
			
			if(s.getText().equalsIgnoreCase("LYCA")){
				
				s.click();
				
			}
			
		}
		
		Thread.sleep(2000);
		String exp_Text = "ESHOPUSERNAME";
		WebElement pagination = driver.findElement(By.id("sp_1_manageConfigPager"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", pagination);
		String paginationValue = pagination.getText();
		
		int count = Integer.parseInt(paginationValue);
		
		System.out.println("paginationValue :"+paginationValue);
		System.out.println("loop count value :"+count);
		
		for(int i = 1; i <= count; i++){
			
			try{
				
			WebElement highlight = driver.findElement(By.xpath("//td[text()='ESHOPUSERNAME' and (contains(@style, 'text-align:center;'))]"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", highlight);
			String title = highlight.getText();
			
			System.out.println("Actual text :"+title);
				
				if(title.equalsIgnoreCase(exp_Text)){
					System.out.println("Element is available in table");
					break;
					} 
				
			}catch(NoSuchElementException e){
				
				System.out.println("Element is not available, Clicking on pagination "+i+"");
				WebElement pageClick = driver.findElement(By.xpath("//*[@id='next_manageConfigPager']/span"));
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", pageClick);
				pageClick.click();
				
			}
				
		}
		
		driver.quit();
		
	}
	
	
	
	public static void scrollPagination(){
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:7656/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		waitUntilExistID("dropdownMenu1");
		driver.findElement(By.id("dropdownMenu1")).click();
		driver.findElement(By.id("settingsMenu")).click();
		waitUntilExistID("Configuration");
		driver.findElement(By.id("Configuration")).click();
		waitUntilExistXpath("//*[@class='well well-sm brandConfigTile dropdown']//text()[normalize-space()='GBR']/following-sibling::div//span[@class='caret']");
		
		driver.findElement(By.xpath("//*[@class='well well-sm brandConfigTile dropdown']//text()[normalize-space()='GBR']/following-sibling::div//span[@class='caret']")).click();
		
		List<WebElement> dropdownVal = driver.findElements(By.xpath("//*[@class='well well-sm brandConfigTile dropdown']//text()[normalize-space()='GBR']/following-sibling::div//ul[@class='dropdown-menu']/child::li"));
		
		for(WebElement s : dropdownVal){
			
			System.out.println(s.getText());
			
			if(s.getText().equalsIgnoreCase("LYCA")){
				
				s.click();
				
			}
			
		}
		
		List<WebElement> scrollBar = driver.findElements(By.xpath("//div[@class='slimScrollBar']"));
		List<WebElement> checkExpectedElement = driver.findElements(By.xpath("//td[@title='Dataformat' and (contains(@style,'text-align:center'))]"));
		
		//if scroll bar exist 
		
		if(scrollBar.size() != 0){
			
			System.out.println("Scroll bar available");
			
			//Check element is present on page
			if(checkExpectedElement.size() != 0){
				
				System.out.println("Element is present on page");
				
				WebElement checkExpectedElement1 = driver.findElement(By.xpath("//td[@title='Dataformat' and (contains(@style,'text-align:center'))]"));
				Coordinates cor = ((Locatable)checkExpectedElement1).getCoordinates();
				cor.onPage();
				cor.inViewPort();
					
					System.out.println("ExpectedElement from table in first page :"+checkExpectedElement1.getText());
				
			} else{
				
				System.out.println("Element is not available on first page");
				WebElement paginationCount = driver.findElement(By.xpath("//span[@id='sp_1_manageConfigPager']"));
				Coordinates corpageCount = ((Locatable)paginationCount).getCoordinates();
				corpageCount.onPage();
				corpageCount.inViewPort();
				System.out.println("Coordinates works fine");
				
				//Converts String to integer
				String pageCount = paginationCount.getText();
				int count = Integer.parseInt(pageCount);
				
				System.out.println("Got the page count");
				
				//Through loop, finding the element by page count
				for(int i = 1; i <= count; i++){
					
					WebElement paginationClick = driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-seek-next']"));
					Coordinates corClick = ((Locatable)paginationClick).getCoordinates();
					corClick.onPage();
					corClick.inViewPort();
					paginationClick.click();
					
					System.out.println("checkExpectedElement.size() :"+checkExpectedElement.size());
					
					//If element is present on page, it will find the text
					if(checkExpectedElement.size() == 0){
						
						WebElement checkExpectedElement1 = driver.findElement(By.xpath("//td[@title='Dataformat' and (contains(@style,'text-align:center'))]"));
						Coordinates corPageCheck = ((Locatable)checkExpectedElement1).getCoordinates();
						corPageCheck.onPage();
						corPageCheck.inViewPort();
							
							System.out.println("ExpectedElement from table in pagination "+i+" :"+checkExpectedElement1.getText());
							break;
							
					}
					
				}
				
			}
			
		}
		
		driver.quit();
		
	}
	
	
	public static void waitExistToElementPresent(){
		
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:7656/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		waitUntilExistID("dropdownMenu1");
		driver.findElement(By.id("dropdownMenu1")).click();
		driver.findElement(By.id("settingsMenu")).click();
		waitUntilExistID("Configuration");
		driver.findElement(By.id("Configuration")).click();
		waitUntilExistXpath("//*[@class='well well-sm brandConfigTile dropdown']//text()[normalize-space()='GBR']/following-sibling::div//span[@class='caret']");
		
		driver.findElement(By.xpath("//*[@class='well well-sm brandConfigTile dropdown']//text()[normalize-space()='GBR']/following-sibling::div//span[@class='caret']")).click();
		
		List<WebElement> dropdownVal = driver.findElements(By.xpath("//*[@class='well well-sm brandConfigTile dropdown']//text()[normalize-space()='GBR']/following-sibling::div//ul[@class='dropdown-menu']/child::li"));
		
		for(WebElement s : dropdownVal){
			
			System.out.println(s.getText());
			
			if(s.getText().equalsIgnoreCase("LYCA")){
				
				s.click();
				
			}
			
		}
//		List<WebElement> scrollBar = driver.findElements(By.xpath("//div[@class='slimScrollBar']"));
		
		JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
		
//		boolean b = (boolean) jsExecutor.executeScript("document.evaluate(\"//td[@title='trMsisdn'and(contains(@style,'text-align:center'))]\", document, null, XPathResult.STRING_TYPE, null)");
		
		boolean b=(boolean) jsExecutor.executeScript("if(document.getElementByXpath(\"//td[@title='trMsisdn'and(contains(@style,'text-align:center'))]\")){return true;}else{return false;}");
		
		if(b){
			
			System.out.println("Element is available");
			
		}else{
			
			System.out.println("Element is not available");
			
		}
		
		driver.quit();
		
	}
	
	public static void regexText(){
		
		String dbValue = "2016-06-21";
		String webValue = "2016-06";
		
		String[] splitted = dbValue.split("\\-");
		String splittedDBValue = splitted[0] +"-" +splitted[1];
		
		System.out.println("splittedDBValue :"+splittedDBValue);
		
		Pattern pattern = Pattern.compile(splittedDBValue);
		Matcher matcher = pattern.matcher(webValue);
		
		while(matcher.find()){
			
			System.out.println(matcher.group());
			
		}
		
	}
	
	public static void waitUntilExistID(String locator){
		
		WebDriverWait ww = new WebDriverWait(driver, 30);
		ww.until(ExpectedConditions.visibilityOfElementLocated(By.id(locator)));
		
	}
	
	public static void waitUntilExistXpath(String locator){
		
		WebDriverWait ww = new WebDriverWait(driver, 30);
		ww.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
		
	}
	
	
	public static void main(String[] args) throws InterruptedException {
		
//		getTableValuesByIterate();
//		getTableValuesByEntering();
//		scrollPagination();
		waitExistToElementPresent();
//		regexText();
		
		
	}
	
}
