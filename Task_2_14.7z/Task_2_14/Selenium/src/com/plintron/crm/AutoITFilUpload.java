package com.plintron.crm;

import java.awt.AWTException;
import java.awt.Robot;
import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.jacob.com.LibraryLoader;

import autoitx4java.AutoItX;

	public class AutoITFilUpload {
	public static WebDriver driver;	
	
	public static void fileUpload() throws InterruptedException, AWTException{
		
		File file = new File("lib", "jacob-1.14.3-x86.dll");
		System.setProperty(LibraryLoader.JACOB_DLL_PATH, file.getAbsolutePath());
		System.setProperty(LibraryLoader.JACOB_DLL_PATH, "D:\\codes\\jars\\jacob-1.14.3-x86\\jacob-1.14.3-x86.dll");
		LibraryLoader.loadJacobLibrary();
		System.out.println("Success");
		File localPath = new File("input/images.jpg");
		String filePath = localPath.getAbsolutePath();
		AutoItX autoit = new AutoItX();
		
//		String notepad = "Untitled - Notepad";
//		String testString = "this is a test.";
//		autoit.run("notepad.exe","",AutoItX.SW_SHOW);
//		autoit.winActivate(notepad);
//		autoit.winWaitActive(notepad);
//		autoit.send(testString);
		
		Chrome();
		autoit.winWaitActive("Open");
		autoit.send(filePath);
		autoit.controlSend("Open","Open","","{ENTER}",false);
		Thread.sleep(7000);
		driver.quit();
		System.out.println("Success");
		
	}
	
	
	public static void Chrome() throws InterruptedException{
		
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("file:///C:/Users/prav2435.PLINTRON/Desktop/Registration.aspx.html");
		Thread.sleep(1000);
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_Reg_FRA1_lnkUploadFile")).click();
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_Reg_FRA1_fuDocIDProof")).click();
		Thread.sleep(1000);
		
	}
	
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		fileUpload();
		
	}
	
	
}
