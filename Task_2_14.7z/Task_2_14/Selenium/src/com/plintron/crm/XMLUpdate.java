package com.plintron.crm;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XMLUpdate {
	static DocumentBuilderFactory factory =null;
	static DocumentBuilder builder=null;
	static XPath xpath=null;
	static XPathFactory xpathfactory=null;
	static NodeList nodeList=null;
	static File file=null;
	static Document document=null;

	/*public static void main(String[] args) throws XPathExpressionException, TransformerException, SAXException, IOException, ParserConfigurationException {
		
		String XMLConfigPath="192.168.110.157\\d$\\BSS_Automation\\CBOS_ITG_API\\Environment\\Development_Environment\\Automation_Application\\CBOS_ITG_API_1\\App_Data\\CountryList_func.xml";
		
		String XPath="CountryList/Countrys/Country[@CountryID='USA']/BrandID[1]/Brand";
		String valuetoSet="ITGSIM:11:CBOSAUTO_UPDATED";
		
		factory=DocumentBuilderFactory.newInstance();
		builder=factory.newDocumentBuilder();
		file=new File("//\\"+XMLConfigPath);

		document=builder.parse(file);
		document.getDocumentElement().normalize();
		NodeList nodeList=null;
		xpath=XPathFactory.newInstance().newXPath();
		nodeList=(NodeList)xpath.compile(XPath).evaluate(document,XPathConstants.NODESET);

		nodeList.item(0).setNodeValue(valuetoSet);
		TransformerFactory transFormerFactory = TransformerFactory.newInstance();
		Transformer transFormer = transFormerFactory.newTransformer();
		DOMSource source = new DOMSource(document);

		StreamResult result = new StreamResult(file);
		transFormer.transform(source, result);
	}*/

	
	public static void test() throws ParserConfigurationException, SAXException, IOException, XPathExpressionException, TransformerException{
		
		DocumentBuilderFactory docbuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docbuilder = docbuilderFactory.newDocumentBuilder();
		File fileinput = new File("input/CountryList_func.xml");
		Document configdoc = docbuilder.parse(fileinput);
		XPath configxpath = XPathFactory.newInstance().newXPath();
		
		String configxpathexpression = "//Brand[@BrandId='ITGSIM:11:DEEPAK']";
		
		//Using node and elements to get the all child attributes 
		NodeList confignodeList = (NodeList) configxpath.compile(configxpathexpression).evaluate(configdoc, XPathConstants.NODESET);
		
		for(int i = 0; i<confignodeList.getLength(); i++){
			
			Node nNode = confignodeList.item(i);
			
			if(nNode.getNodeType() == Node.ELEMENT_NODE){
				
				Element eElement = (Element) nNode;
				if(eElement.getAttribute("BrandId") != null){
					
					String prevValue = eElement.getAttribute("BrandId");
					System.out.println("Current Value :"+prevValue);
					
					eElement.setAttribute("BrandId", "//Brand[@BrandId='ITGSIM:11:PRAVEEN']");
					
					String newValue = eElement.getAttribute("BrandId");
					
					System.out.println("Updated Value :"+newValue);
				} else {
					
					System.out.println("Given attribute value is not available");
					
				}
			}
		}
		
		System.out.println("Success");
		
		
	}
	
	
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException, TransformerException {
		
		test();
	}
	
	
	
	
	
}
