package com.plintron.crm;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Approval {

	public static WebDriver driver;

	public static void getAllPendingApprovalCounts(){
		
		
		File fileBrowser = new File("input//IEDriverServer.exe");
		System.setProperty("webdriver.ie.driver", fileBrowser.getAbsolutePath());
		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
		caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		WebDriver driver = new InternetExplorerDriver(caps);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:6552/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		waitUntilExistID("pendingApproval");
		
		waitUntilExistXpath("//a[text()='SIM Block']/ancestor::tr//a[@class='item-link ng-binding']");
		String simBlock = driver.findElement(By.xpath("//a[text()='SIM Block']/ancestor::tr//a[@class='item-link ng-binding']")).getText();
		System.out.println("simBlock :"+simBlock);
		
		waitUntilExistXpath("//a[text()='SIM UnBlock']/ancestor::tr//a[@class='item-link ng-binding']");
		String SIMUnBlock = driver.findElement(By.xpath("//a[text()='SIM UnBlock']/ancestor::tr//a[@class='item-link ng-binding']")).getText();
		System.out.println("SIMUnBlock :"+SIMUnBlock);
		
		waitUntilExistXpath("//a[text()='Swap IMSI']/ancestor::tr//a[@class='item-link ng-binding']");
		String SwapIMSI = driver.findElement(By.xpath("//a[text()='Swap IMSI']/ancestor::tr//a[@class='item-link ng-binding']")).getText();
		System.out.println("SwapIMSI :"+SwapIMSI);
		
		waitUntilExistXpath("//a[text()='Swap MSISDN']/ancestor::tr//a[@class='item-link ng-binding']");
		String SwapMSISDN = driver.findElement(By.xpath("//a[text()='Swap MSISDN']/ancestor::tr//a[@class='item-link ng-binding']")).getText();
		System.out.println("SwapMSISDN :"+SwapMSISDN);
		
		waitUntilExistXpath("//a[text()='Balance Transfer']/ancestor::tr//a[@class='item-link ng-binding']");
		String BalanceTransfer = driver.findElement(By.xpath("//a[text()='Balance Transfer']/ancestor::tr//a[@class='item-link ng-binding']")).getText();
		System.out.println("BalanceTransfer :"+BalanceTransfer);
		
		waitUntilExistXpath("//a[text()='Refund Bundle']/ancestor::tr//a[@class='item-link ng-binding']");
		String RefundBundle = driver.findElement(By.xpath("//a[text()='Refund Bundle']/ancestor::tr//a[@class='item-link ng-binding']")).getText();
		System.out.println("RefundBundle :"+RefundBundle);
		
		waitUntilExistXpath("//a[text()='Refund Topup']/ancestor::tr//a[@class='item-link ng-binding']");
		String RefundTopup = driver.findElement(By.xpath("//a[text()='Refund Topup']/ancestor::tr//a[@class='item-link ng-binding']")).getText();
		System.out.println("RefundTopup :"+RefundTopup);
		
		waitUntilExistXpath("//a[text()='Staff Topup']/ancestor::tr//a[@class='item-link ng-binding']");
		String StaffTopup = driver.findElement(By.xpath("//a[text()='Staff Topup']/ancestor::tr//a[@class='item-link ng-binding']")).getText();
		System.out.println("StaffTopup :"+StaffTopup);
		
		waitUntilExistXpath("//a[text()='Change Plan']/ancestor::tr//a[@class='item-link ng-binding']");
		String ChangePlan = driver.findElement(By.xpath("//a[text()='Change Plan']/ancestor::tr//a[@class='item-link ng-binding']")).getText();
		System.out.println("ChangePlan :"+ChangePlan);
		
		waitUntilExistXpath("//a[text()='OBA Plan Upgrade']/ancestor::tr//a[@class='item-link ng-binding']");
		String OBAPlanUpgrade = driver.findElement(By.xpath("//a[text()='OBA Plan Upgrade']/ancestor::tr//a[@class='item-link ng-binding']")).getText();
		System.out.println("OBAPlanUpgrade :"+OBAPlanUpgrade);
		
		waitUntilExistXpath("//a[text()='OBA Additional Credit']/ancestor::tr//a[@class='item-link ng-binding']");
		String OBAAdditionalCredit = driver.findElement(By.xpath("//a[text()='OBA Additional Credit']/ancestor::tr//a[@class='item-link ng-binding']")).getText();
		System.out.println("OBAAdditionalCredit :"+OBAAdditionalCredit);
		
		waitUntilExistXpath("//a[text()='Bundle Bucket']/ancestor::tr//a[@class='item-link ng-binding']");
		String BundleBucket = driver.findElement(By.xpath("//a[text()='Bundle Bucket']/ancestor::tr//a[@class='item-link ng-binding']")).getText();
		System.out.println("BundleBucket :"+BundleBucket);
		
		waitUntilExistXpath("//a[text()='Zipcode Swap MSISDN']/ancestor::tr//a[@class='item-link ng-binding']");
		String ZipcodeSwapMSISDN = driver.findElement(By.xpath("//a[text()='Zipcode Swap MSISDN']/ancestor::tr//a[@class='item-link ng-binding']")).getText();
		System.out.println("ZipcodeSwapMSISDN :"+ZipcodeSwapMSISDN);
		
		driver.findElement(By.xpath("//a[text()='Bundle Bucket']/ancestor::tr//a[@class='item-link ng-binding']")).click();
		
		waitUntilExistID("crmPageHeader");
		
		driver.quit();
		
	}
	
	
	public static void getPendingApprovalSpecValue(){
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:7656/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		waitUntilExistID("pendingApproval");
		waitUntilExistXpath("//a[text()='SIM Block']/ancestor::tr//a[@class='item-link ng-binding']");
		driver.findElement(By.xpath("//a[text()='SIM Block']/ancestor::tr//a[@class='item-link ng-binding']")).click();
		waitUntilExistID("crmPageHeader");
		
		WebElement allDDValues = driver.findElement(By.id("PendingApprovalspan"));
		Select se = new Select(allDDValues);
		se.selectByVisibleText("All");
		
		waitUntilExistXpath("//span[@id='sp_1_pendingItemPager']");
		WebElement pageValue = driver.findElement(By.xpath("//span[@id='sp_1_pendingItemPager']"));
		
		String pageCount = pageValue.getText();
		
		int count = Integer.parseInt(pageCount);
		
		String expectedText = "31";
		
		for(int i = 1; i <= count; i++){
			
			try{
				
				WebElement requestIDInTable = driver.findElement(By.xpath("//text()[normalize-space()='Request ID']/ancestor::div/following-sibling::div//td[@title='31']"));
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", requestIDInTable);
				String requestID = driver.findElement(By.xpath("//text()[normalize-space()='Request ID']/ancestor::div/following-sibling::div//td[@title='31']")).getText();
				
				if(expectedText.equalsIgnoreCase(requestID)){
					
					System.out.println("Element is available");
					System.out.println("Actual Text :"+requestID);
					break;
					
				}
				
				
			}catch(NoSuchElementException e){
				
				e.getMessage();
				System.out.println("Element is not available, Clicking on Pagination "+i);
				waitUntilExistXpath("//span[@class='ui-icon ui-icon-seek-next']");
				driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-seek-next']")).click();
				
			}
			
			
			
		}
		
		driver.quit();
		
	}
	
	
	public static void getCorrespondantValues(){
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("file:///C:/Users/prav2435/Desktop/Home.html");
		
		WebElement requestIDInTable = driver.findElement(By.xpath("//text()[normalize-space()='Request ID']/ancestor::div/following-sibling::div//td[@title='1006']/following-sibling::td"));

		String data = requestIDInTable.getText();
		
		System.out.println(data);
			
		driver.quit();
		
	}
	
	
	public static void getStaffTopUpValue() throws InterruptedException{
		
//		File fileBrowser = new File("input//IEDriverServer.exe");
//		System.setProperty("webdriver.ie.driver", fileBrowser.getAbsolutePath());
//		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
//		caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
//		driver = new InternetExplorerDriver(caps);
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.110.157:2001");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		waitUntilExistID("pendingApproval");
		waitUntilExistXpath("//a[text()='Staff Topup']/ancestor::tr//a[@class='item-link ng-binding']");
		WebElement staff_TP = driver.findElement(By.xpath("//a[text()='Staff Topup']/ancestor::tr//a[@class='item-link ng-binding']"));
		Coordinates corPageCheck = ((Locatable)staff_TP).getCoordinates();
		corPageCheck.onPage();
		corPageCheck.inViewPort();
		staff_TP.click();
		
		waitUntilExistID("crmPageHeader");
		String staff_MSISDN = "//text()[normalize-space()='Request ID']/ancestor::div/following-sibling::div//td[@title='65']/following-sibling::td[@aria-describedby='pendingItemTable_Msisdn']//a";
		
		Object mSISDNStatus = jsExecChkValExist(staff_MSISDN);
		
		System.out.println("countStatus :"+mSISDNStatus);
		
		if(mSISDNStatus.equals(true)){
			
			System.out.println("Element is available on first page");
			WebElement staff_MS = driver.findElement(By.xpath(staff_MSISDN));
			staff_MS.click();
			
		}else{
			
			WebElement pageCount = driver.findElement(By.xpath("//span[@id='sp_1_pendingItemPager']"));
			String strCount = pageCount.getText();
			System.out.println("Count :" +strCount);
			
			int count = Integer.parseInt(strCount);
			System.out.println("Element is not available on first page, Clicking on pagination");
			
			for(int i = 1; i<=count; i++){
				
				driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-seek-next']")).click();
				
				System.out.println("Clicking on pagination :"+i);
				
				mSISDNStatus = jsExecChkValExist(staff_MSISDN);
				
				if(mSISDNStatus.equals(true)){
					
					WebElement staff_MS1 = driver.findElement(By.xpath(staff_MSISDN));
					staff_MS1.click();
					Thread.sleep(4000);
					System.out.println("Element found in pagination :"+mSISDNStatus);
					break;
					
				}
				
			}
			
			
		}
		
		driver.quit();
		
	}
	
	
	public static void acceptAlphabets(){
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("file:///C:/Users/prav2435/Desktop/page/page/usa_register.htm");
		
		driver.findElement(By.id("txtfirstName")).sendKeys("ABCD");
		
		String element = driver.findElement(By.id("txtfirstName")).getAttribute("value");
		
		System.out.println("****** :"+element);
		
		driver.quit();
		
		
	}
	
	
	public static Object jsExecChkValExist(String locator){
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Object scrollBarStatus = js.executeScript("return document.evaluate(\""+locator+"\",document.body,null,XPathResult.UNORDERED_NODE_ITERATOR_TYPE,null).iterateNext()!=null;");
		return scrollBarStatus;
		
	}
	
	
	public static void waitUntilExistID(String locator){
		
		WebDriverWait ww = new WebDriverWait(driver, 30);
		WebElement waituntilExist = ww.until(ExpectedConditions.visibilityOfElementLocated(By.id(locator)));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", waituntilExist);
		
	}
	
	public static void waitUntilExistXpath(String locator){
		
		WebDriverWait ww = new WebDriverWait(driver, 30);
		WebElement waituntilExist = ww.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", waituntilExist);
		
	}
	
	
	public static void main(String[] args) throws InterruptedException {
		
		
//		acceptAlphabets();
		getStaffTopUpValue();
//		getAllPendingApprovalCounts();
//		getPendingApprovalSpecValue();
//		getCorrespondantValues();
	}
	
}
