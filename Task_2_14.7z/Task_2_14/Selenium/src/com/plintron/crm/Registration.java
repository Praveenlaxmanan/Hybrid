package com.plintron.crm;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Registration {
	
	public static WebDriver driver;
	
	public static void newRegister() throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:7656/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		waitUntilExistID("subsParameter");
		driver.findElement(By.id("subsParameter")).sendKeys("(447)-87-120-029-8");
		driver.findElement(By.id("btnNewRegister")).click();
		waitUntilExistXpath("//div[text()='Personal Information']");
		selectDropdown("ddlTitle", "Dr");
		driver.findElement(By.id("txtfirstName")).sendKeys("FirstName");
		driver.findElement(By.id("txtlastName")).sendKeys("LastName");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('txtdateofbirth').value = '23/06/1995'");
		driver.findElement(By.id("txtCounty")).sendKeys("US");
		driver.findElement(By.id("txtCode_1")).sendKeys("600021");
		driver.findElement(By.id("txtState")).sendKeys("LasVegas");				  	
		driver.findElement(By.id("txtCity_1")).sendKeys("LasVegas");
		driver.findElement(By.id("txtLine1_1")).sendKeys("12");
		driver.findElement(By.id("txtLine2_1")).sendKeys("AutoSt");
		driver.findElement(By.id("txtHouseName")).sendKeys("TestName");
		driver.findElement(By.id("txtEmail1")).sendKeys("auto22@plintron.com");
		driver.findElement(By.id("txtContact1")).sendKeys("9962353535");
		waitUntilExistID("txtPukCode");
		driver.findElement(By.id("txtPukCode")).sendKeys("8120000");
		selectDropdown("GBRLang", "English");
		selectDropdown("ddlHearAbout", "Newspaper");
		driver.findElement(By.id("Next")).click();
		
		waitUntilExistXpath("//label[text()='Title']");
		
		String conTitleSelect = driver.findElement(By.id("step2Title")).getText();
		System.out.println("conTitleSelect :" +conTitleSelect );
		
		String conFirstName = driver.findElement(By.id("step2FirstName")).getText();
		System.out.println("conFirstName :" +conFirstName );
		
		String conLastName = driver.findElement(By.id("step2LastName")).getText();
		System.out.println("conLastName :" +conLastName );
		
		String conDOB = driver.findElement(By.id("step2dob")).getText();
		System.out.println("conDOB :" +conDOB );
		
		String conComCountry = driver.findElement(By.id("step2txtCountry_1")).getText();
		System.out.println("conComCountry :" +conComCountry );
		
		String conCountry = driver.findElement(By.id("step2txtCounty")).getText();
		System.out.println("conCountry :" +conCountry );
		
		String conState = driver.findElement(By.id("step2txtState")).getText();
		System.out.println("conState :" +conState );
		
		String conCity = driver.findElement(By.id("step2txtCity_1")).getText();
		System.out.println("conCity :" +conCity );
		
		String conStreet = driver.findElement(By.id("step2txtStreet_1")).getText();
		System.out.println("conStreet :" +conStreet );
		
		String conHouNo = driver.findElement(By.id("step2House_Number")).getText();
		System.out.println("conHouNo :" +conHouNo );
		
		String conHouName = driver.findElement(By.id("step2HouseName")).getText();
		System.out.println("conHouName :" +conHouName );
		
		String conEmail = driver.findElement(By.id("step2txtEmail1")).getText();
		System.out.println("conEmail :" +conEmail );
		
		String conContactNo = driver.findElement(By.id("step2txtContactNumber_1")).getText();
		System.out.println("conContactNo :" +conContactNo );
		
		String conMSISDN = driver.findElement(By.id("step2MSISDN_Number")).getText();
		System.out.println("conMSISDN :" +conMSISDN );
		
		String conPUK = driver.findElement(By.id("step2PUK_Number")).getText();
		System.out.println("conPUK :" +conPUK );
		
		String conHearAboutUs = driver.findElement(By.id("step2hear_about")).getText();
		System.out.println("conHearAboutUs :" +conHearAboutUs );
		
		String conLang = driver.findElement(By.id("step2Language")).getText();
		System.out.println("conLang :" +conLang );
		
		driver.findElement(By.id("Submit")).click();
		
		driver.quit();
		
	}
	
	public static void newPortIn() throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:7656/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		waitUntilExistID("subsParameter");
		driver.findElement(By.id("subsParameter")).sendKeys("(447)-87-120-029-8");
		driver.findElement(By.id("btnPortin")).click();
		waitUntilExistID("Billing");
		driver.findElement(By.id("txtPFirstName")).sendKeys("FirstName");
		driver.findElement(By.id("txtPLastName")).sendKeys("LastName");
		
		waitUntilExistID("txtPMsisdn");
//		String mobileNo = driver.findElement(By.id("txtPMsisdn")).getText();
//		System.out.println("************** :"+mobileNo);
		
		driver.findElement(By.id("txtPIccid")).sendKeys("1234");
		driver.findElement(By.id("txtMsisdn")).sendKeys("19912510026");
		driver.findElement(By.id("txtIccId")).sendKeys("5678");
		driver.findElement(By.id("txtPUniqueId")).sendKeys("123456");
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('PortindatePick').value = '30/06/2016'");
		
		driver.findElement(By.id("txtEmail")).sendKeys("praveen.ld@plintron.co");
		selectDropdown("ddlPrelngue", "English");
		selectDropdown("ddlDSP", "T-Mobile");
		driver.findElement(By.id("btnSubPortin")).click();
		driver.quit();
	
	}
	
	
	public static void postPaidRegistration() throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:7656/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		waitUntilExistID("subsParameter");
		driver.findElement(By.id("subsParameter")).sendKeys("(447)-87-120-029-8");
		driver.findElement(By.id("btnCommonPostPaid")).click();
		waitUntilExistID("ddPlanType");
		Thread.sleep(2000);
		selectDropdown("ddPlanType", "Retail");
		waitUntilExistID("ddTitle");
		selectDropdown("ddTitle", "Dr");
		waitUntilExistID("CustomerDetails_AcademicTitle");
		driver.findElement(By.id("CustomerDetails_AcademicTitle")).sendKeys("Academic");
		driver.findElement(By.id("CustomerDetails_FirstName")).sendKeys("FirstName");
		driver.findElement(By.id("CustomerDetails_LastName")).sendKeys("LastName");
		selectDropdown("ddCorporate", "CUSTOMER3");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('CustomerDetails_DateOfBirth').value = '23/06/1995'");
		driver.findElement(By.id("CustomerDetails_PlaceofBirth")).sendKeys("PlaceofBirth");
		selectDropdown("CustomerDetails_Nationality", "India");
		selectDropdown("ddGender", "M");
		driver.findElement(By.id("txtHouseNo")).sendKeys("12");
		driver.findElement(By.id("txtHouseName")).sendKeys("testHouse");
		driver.findElement(By.id("txtStreet")).sendKeys("testStreet");
		driver.findElement(By.id("ddCity")).sendKeys("LasVegas");
		driver.findElement(By.id("txtPostCode")).sendKeys("20910");
		driver.findElement(By.id("rbtnSameResidence")).click();
		selectDropdown("ddMsisdnAvailable", "Not Available");
		selectDropdown("ddMSISDN", "442904011007");
		driver.findElement(By.id("CustomerDetails_Email")).sendKeys("test12345@plintron.com");
		driver.findElement(By.id("CustomerDetails_ContactNumber")).sendKeys("9962353535");
		driver.findElement(By.id("CustomerDetails_Deposit")).sendKeys("500");
		selectDropdown("ddlbillcycle", "30th, Every 1 Year(s)");
		driver.findElement(By.id("CustomerDetails_SIMNo")).sendKeys("0987");
		driver.findElement(By.id("CustomerDetails_PUKCode")).sendKeys("81220000");
		selectDropdown("ddSimType", "Nano Sim");
		selectDropdown("ddMostCall", "United States");
		driver.findElement(By.id("CustomerDetails_IdNo")).sendKeys("G1985335");
		selectDropdown("ddDocumentType", "Passport");
		selectDropdown("ddLanguage", "English");
		driver.findElement(By.id("CustomerDetails_VAT_Reg_No")).sendKeys("2102312");
		selectDropdown("CustomerDetails_NDDPreference", "Unlisted");
		driver.findElement(By.id("CustomerDetails_TaxCode")).sendKeys("159753");
		driver.findElement(By.id("CustomerDetails_Occupation")).sendKeys("Test");
		driver.findElement(By.id("CustomerDetails_Qualification")).sendKeys("Test_Qualify");
		selectDropdown("ddHeardaboutus", "Newspaper");
		selectDropdown("ddSecretQues", "What is your pet name?");
		driver.findElement(By.id("CustomerDetails_SecretAnswer")).sendKeys("R1");
		driver.findElement(By.id("CustomerDetails_Issuer")).sendKeys("Testing_Authorty");
		js.executeScript("document.getElementById('CustomerDetails_IssueFullDate').value = '23/06/2016'");
		js.executeScript("document.getElementById('CustomerDetails_IDValidateFullDate').value = '23/06/2026'");
		selectDropdown("CustomerDetails_CreditCheckstatus", "Success");
		selectDropdown("CustomerDetails_IncludePhBook", "Yes");
		driver.findElement(By.id("CustomerDetails_PIN")).sendKeys("1234");
		driver.findElement(By.id("ConfirmPIN")).sendKeys("1234");
		driver.findElement(By.id("CustomerDetails_Remarks")).sendKeys("Test_Notes");
		driver.findElement(By.id("cbxAgree")).click();
		driver.findElement(By.id("Next")).click();
		
	}
	
	
	public static void manageUserSettings() throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:7656/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		waitUntilExistID("dropdownMenu1");
		driver.findElement(By.id("dropdownMenu1")).click();
		driver.findElement(By.id("settingsMenu")).click();
		waitUntilExistID("UserManagement");
		driver.findElement(By.id("UserManagement")).click();
		waitUntilExistID("bundleToggler1");
		driver.findElement(By.id("bundleToggler1")).click();
		
		Thread.sleep(2000);
		String exp_Text = "ESHOPUSERNAME";
		WebElement pagination = driver.findElement(By.id("sp_1_manageConfigPager"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", pagination);
		String paginationValue = pagination.getText();
		
		int count = Integer.parseInt(paginationValue);
		
		System.out.println("paginationValue :"+paginationValue);
		System.out.println("loop count value :"+count);
		
		for(int i = 1; i <= count; i++){
			
			try{
				
			WebElement highlight = driver.findElement(By.xpath("//td[text()='ESHOPUSERNAME' and (contains(@style, 'text-align:center;'))]"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", highlight);
			String title = highlight.getText();
			
			System.out.println("Actual text :"+title);
				
				if(title.equalsIgnoreCase(exp_Text)){
					System.out.println("Element is available in table");
					break;
					} 
				
			}catch(NoSuchElementException e){
				
				System.out.println("Element is not available, Clicking on pagination "+i+"");
				WebElement pageClick = driver.findElement(By.xpath("//*[@id='next_manageConfigPager']/span"));
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", pageClick);
				pageClick.click();
				
			}
				
		}
		
		driver.quit();
		
	}
	
	
	public static void countryText() throws InterruptedException{
		
//		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
//		caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		System.setProperty("webdriver.ie.driver", "input//IEDriverServer.exe");
		driver = new InternetExplorerDriver();
//		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
//		driver = new ChromeDriver();
		driver.get("file:///C:/Users/prav2435/Desktop/page/page/register.htm");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		System.out.println("Start");
		Thread.sleep(3000);
		
		String countryText = driver.findElement(By.xpath("//*[@id='txtCountry_1']")).getAttribute("value");
		
		System.out.println("*******" +countryText);
		
		driver.quit();
		
	}
	
	

	public static void waitUntilExistID(String locator){
		
		WebDriverWait ww = new WebDriverWait(driver, 30);
		ww.until(ExpectedConditions.visibilityOfElementLocated(By.id(locator)));
		
	}
	
	public static void waitUntilExistXpath(String locator){
		
		WebDriverWait ww = new WebDriverWait(driver, 30);
		ww.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
		
	}
	
	public static void selectDropdown(String locator, String text){
		
		WebElement element = driver.findElement(By.id(locator));
		Select se = new Select(element);
		se.selectByVisibleText(text);
		
	}
	
	public static void main(String[] args) throws InterruptedException {
		
//		newRegister();
//		newPortIn();
//		postPaidRegistration();
		countryText();
	
	}
	
	
	
}
