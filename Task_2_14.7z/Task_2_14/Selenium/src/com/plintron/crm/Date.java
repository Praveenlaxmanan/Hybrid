package com.plintron.crm;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Date {
	
	public static WebDriver driver;
	
	public static void datePicker() throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:7656/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		driver.findElement(By.id("subsParameter")).sendKeys("(447)-87-120-029-8");
		driver.findElement(By.id("btnNewRegister")).click();
		Thread.sleep(7000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('txtdateofbirth').setAttribute('value', '01/30/2013')");
		Thread.sleep(2000);
		driver.findElement(By.id("Next")).click();
		Thread.sleep(3000);
		driver.quit();
	}
	
	
	public static void filterTickets() throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:7656/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		Thread.sleep(5000);
		
		WebElement dropdown = driver.findElement(By.id("loadType"));
		Select se = new Select(dropdown);
		se.selectByVisibleText("MSISDN");
		
		driver.findElement(By.id("loadParameter")).sendKeys("(447)-87-120-029-6");
		driver.findElement(By.id("btnLoadSubscriber")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.id("filterTickets")).click();
		List<WebElement> filtersSelect = driver.findElements(By.id("ulFilderTickets"));
		
		for(WebElement allOptions : filtersSelect){
			
			if(allOptions.equals("Open")){
				
				allOptions.click();
				break;
			}
		}
		
//		22657676
		
		
	}
	
	
	
	public static void scrollSpecificElement() throws InterruptedException, IOException{
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:7656/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		Thread.sleep(5000);
		
		WebElement dropdown = driver.findElement(By.id("loadType"));
		Select se = new Select(dropdown);
		se.selectByVisibleText("MSISDN");
		
		driver.findElement(By.id("loadParameter")).sendKeys("(447)-87-120-029-6");
		driver.findElement(By.id("btnLoadSubscriber")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.className("create-ticket")).click();
		
		WebElement product = driver.findElement(By.id("Productspan"));
		Select se1 = new Select(product);
		se1.selectByVisibleText("LycaBroadBand");
		
		WebElement category = driver.findElement(By.id("Categoryspan"));
		Select cat = new Select(category);
		cat.selectByVisibleText("Blank calls");
		
		WebElement subCate = driver.findElement(By.id("SubCategoryspan"));
		Select subCat = new Select(subCate);
		subCat.selectByVisibleText("1541");
		
		WebElement destination = driver.findElement(By.id("Designationspan"));
		Select destDD = new Select(destination);
		destDD.selectByVisibleText("Albania Proper");
		
		driver.findElement(By.xpath("//*[@id='AddForm']/div/div/div[8]/div/span")).click();
		
		Runtime.getRuntime().exec("input//CRM_upload_file.exe");
		
		WebDriverWait ww = new WebDriverWait(driver, 30);
		ww.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='divAddAttachment']/span")));
		
		driver.findElement(By.id("txtDescription")).sendKeys("Test description");
		
		WebElement createButton = driver.findElement(By.id("create"));
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", createButton);
		
		WebElement assignTo = driver.findElement(By.id("Assigntospan"));
		Select assignSelect = new Select(assignTo);
		assignSelect.selectByVisibleText("ASRUSER");
		
		WebElement priority = driver.findElement(By.id("Priorityspan"));
		Select prioSelect = new Select(priority);
		prioSelect.selectByVisibleText("C1:High");
		
		WebElement fcr = driver.findElement(By.id("FCR"));
		Select fcrSelect = new Select(fcr);
		fcrSelect.selectByVisibleText("Yes");
		
		WebElement customerFB = driver.findElement(By.id("CustFeedBackspan"));
		Select custFBSelect = new Select(customerFB);
		custFBSelect.selectByVisibleText("Highly satisfied");
		
		js.executeScript("document.getElementById('txtEstCloDate').value = '15/06/2016'");
		
		createButton.click();
		
		Thread.sleep(5000);
		
		WebDriverWait conf_message = new WebDriverWait(driver, 50);
		conf_message.until(ExpectedConditions.visibilityOfElementLocated(By.id("ErrmsgClose")));
		
		driver.findElement(By.id("ErrmsgClose")).click();
		
		driver.quit();
	}
	
	
	public static void uploadFilesUsingAutoIT() throws InterruptedException, IOException{
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:7656/");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		Thread.sleep(5000);
		
		WebElement dropdown = driver.findElement(By.id("loadType"));
		Select se = new Select(dropdown);
		se.selectByVisibleText("MSISDN");
		
		driver.findElement(By.id("loadParameter")).sendKeys("(447)-87-120-029-6");
		driver.findElement(By.id("btnLoadSubscriber")).click();
		Thread.sleep(5000);
		driver.findElement(By.className("create-ticket")).click();
		
		WebElement product = driver.findElement(By.id("Productspan"));
		Select se1 = new Select(product);
		se1.selectByVisibleText("LycaBroadBand");
		
		WebElement category = driver.findElement(By.id("Categoryspan"));
		Select cat = new Select(category);
		cat.selectByVisibleText("Blank calls");
		
		WebElement subCate = driver.findElement(By.id("SubCategoryspan"));
		Select subCat = new Select(subCate);
		subCat.selectByVisibleText("1541");
		
		WebElement destination = driver.findElement(By.id("Designationspan"));
		Select destDD = new Select(destination);
		destDD.selectByVisibleText("Albania Proper");
		
		driver.findElement(By.xpath("//*[@id='AddForm']/div/div/div[8]/div/span")).click();
		
		Runtime.getRuntime().exec("input//CRM_upload_file.exe");
		
		WebDriverWait ww = new WebDriverWait(driver, 30);
		ww.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='divAddAttachment']/span")));
		
		WebElement createButton = driver.findElement(By.id("create"));
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", createButton);
		
		createButton.click();
		
		Thread.sleep(5000);
		
		driver.quit();
	}
	
	
	public static void processKill() throws IOException{
		
		Runtime rt = Runtime.getRuntime();
		rt.exec("taskkill /F /IM IE8_browser_update.exe");
		System.out.println("Process killed");
	}
	
	public static void createNewTicket() throws InterruptedException, IOException{
		
		System.setProperty("webdriver.ie.driver", "input//IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.109.148:6552");
		driver.findElement(By.id("UserName")).sendKeys("admin");
		driver.findElement(By.id("Password")).sendKeys("123456");
		driver.findElement(By.id("Login")).click();
		waitUntilExistID("loadType");
		
		WebElement dropdown = driver.findElement(By.id("loadType"));
		Select se = new Select(dropdown);
		se.selectByVisibleText("MSISDN");
		
		driver.findElement(By.id("loadParameter")).sendKeys("449944004001");
		driver.findElement(By.id("btnLoadSubscriber")).click();
		waitUntilExistXpath("//div[@title='Create Ticket']");
		
		driver.findElement(By.xpath("//div[@title='Create Ticket']")).click();
		
		WebElement product = driver.findElement(By.id("Productspan"));
		Select se1 = new Select(product);
		se1.selectByVisibleText("LycaBroadBand");
		
		WebElement category = driver.findElement(By.id("Categoryspan"));
		Select cat = new Select(category);
		cat.selectByVisibleText("Blank calls");
		
		WebElement subCate = driver.findElement(By.id("SubCategoryspan"));
		Select subCat = new Select(subCate);
		subCat.selectByVisibleText("1541");
		
		WebElement destination = driver.findElement(By.id("Designationspan"));
		Select destDD = new Select(destination);
		destDD.selectByVisibleText("Albania Proper");
		
		driver.findElement(By.xpath("//*[@id='AddForm']/div/div/div[8]/div/span")).click();
		
		Runtime.getRuntime().exec("input//CRM_upload_file.exe");
		
		Thread.sleep(4000);
		
		WebDriverWait ww = new WebDriverWait(driver, 30);
		ww.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='divAddAttachment']/span")));
		
		
		driver.findElement(By.id("txtDescription")).sendKeys("Test description");
		
		WebElement highlightElement = driver.findElement(By.id("Assigntospan"));
		
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", highlightElement);
		
		WebElement assignTo = highlightElement;
		Select assignSelect = new Select(assignTo);
		assignSelect.selectByVisibleText("ASRUSER");
		
		WebElement priority = driver.findElement(By.id("Priorityspan"));
		Select prioSelect = new Select(priority);
		prioSelect.selectByVisibleText("C1:High");
		
		WebElement fcr = driver.findElement(By.id("FCR"));
		Select fcrSelect = new Select(fcr);
		fcrSelect.selectByVisibleText("Yes");
		
		WebElement customerFB = driver.findElement(By.id("CustFeedBackspan"));
		Select custFBSelect = new Select(customerFB);
		custFBSelect.selectByVisibleText("Highly satisfied");
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('txtEstCloDate').value = '29/06/2016'");
		
		WebElement createButton = driver.findElement(By.id("create"));
		createButton.click();
		
		waitUntilExistID("ErrmsgClose");
		
		WebElement ticketID = driver.findElement(By.xpath("//div[contains(text(),'Ticket ID')]"));
		System.out.println(ticketID.isDisplayed());
		String text = ticketID.getText();
		
		System.out.println("******* :" +text);
		
		driver.findElement(By.id("ErrmsgClose")).click();
		
		driver.quit();
		
	}
	
	
	public static void editTicket() throws InterruptedException, IOException{
		
			System.setProperty("webdriver.ie.driver", "input//chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			driver.get("http://192.168.109.148:7656/");
			driver.findElement(By.id("UserName")).sendKeys("admin");
			driver.findElement(By.id("Password")).sendKeys("123456");
			driver.findElement(By.id("Login")).click();
			Thread.sleep(5000);
			
			WebElement dropdown = driver.findElement(By.id("loadType"));
			Select se = new Select(dropdown);
			se.selectByVisibleText("MSISDN");
			
			driver.findElement(By.id("loadParameter")).sendKeys("(447)-87-120-029-6");
			driver.findElement(By.id("btnLoadSubscriber")).click();
			Thread.sleep(5000);
			
			WebElement editTicket = driver.findElement(By.xpath("//span[text()='22657674']/ancestor::div[@class='ticket-header']/following-sibling::div//span[@id='Editbutton']"));
			editTicket.click();
			driver.findElement(By.id("txtAdditionalInfo")).sendKeys("Test description");
			
			WebElement highlightElement = driver.findElement(By.id("EditStatusspan"));
			
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", highlightElement);
			
			WebElement status = highlightElement;
			Select changeStatus = new Select(status);
			changeStatus.selectByVisibleText("In-Progress");
			
			WebElement customerFB = driver.findElement(By.id("txtEditCustFeedBack"));
			Select custFBSelect = new Select(customerFB);
			custFBSelect.selectByVisibleText("Satisfied");
			
			driver.findElement(By.id("update")).click();
			WebDriverWait conf_message = new WebDriverWait(driver, 50);
			conf_message.until(ExpectedConditions.visibilityOfElementLocated(By.id("ErrmsgClose")));
			driver.findElement(By.id("ErrmsgClose")).click();
			driver.quit();
		
	}
	
	
	public static void waitUntilExistID(String locator){
		
		WebDriverWait ww = new WebDriverWait(driver, 60);
		ww.until(ExpectedConditions.visibilityOfElementLocated(By.id(locator)));
		
	}
	
	public static void waitUntilExistXpath(String locator){
		
		WebDriverWait ww = new WebDriverWait(driver, 60);
		ww.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
		
	}
	
	
	public static void checkTicketID() throws InterruptedException{
		
		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
		caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		System.setProperty("webdriver.ie.driver", "input//IEDriverServer.exe");
		driver = new InternetExplorerDriver(caps);
//		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
//		driver = new ChromeDriver();
		driver.get("file:///C:/Users/prav2435.PLINTRON.000/Desktop/Customer%20Relationship%20Management.htm");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		System.out.println("Started ***");
		Thread.sleep(3000);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
//		String xpath = "//*[@id='ErrmsgClose']";
//		Object obj = js.executeScript("document.evaluate(\""+xpath+"\", document, null, XPathResult.BOOLEAN_TYPE, null)");
		Object obj = js.executeScript("return document.evaluate(\"//*[@id='ErrmsgClose']\",document.body,null,XPathResult.UNORDERED_NODE_ITERATOR_TYPE,null).iterateNext()!=null;");
		System.out.println(obj);
		
//		((JavascriptExecutor) driver).executeScript("document.evaluate('"+xpath+"', document, null, XPathResult.ANY_TYPE, null).singleNodeValue");
		/*Object xpathExpression;
		Object on = ((Object) document).evaluate(xpathExpression, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
		if(obj != null) {
		    System.out.println(obj.toString());
		}*/
		
//		JavascriptExecutor executor = (JavascriptExecutor)driver;
//		Object obj = executor.executeScript("return document.activeElement.getElementsByClassName('modal-header')[0].innerHTML.trim();");
//		System.out.println(obj);
		
//		mouseOver(driver.findElement(By.xpath(".//*[@id='ErrmsgClose']")));
		
		driver.quit();
		
	}
	
	public static void mouseOver(WebElement element){
		
		String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript(mouseOverScript, element);
		
	}
	
	
	public static void checkDatePicker() throws InterruptedException{
		
		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
		caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		caps.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "file:///C:/Users/prav2435/Desktop/page/page/complete_registration.htm");
		DesiredCapabilities.internetExplorer().setCapability("ignoreProtectedModeSettings", true);
		System.setProperty("webdriver.ie.driver", "input//IEDriverServer.exe");
		caps.setCapability("IE.binary", "C:\\Program Files\\Internet Explorer\\iexplore.exe");
		caps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		caps.setJavascriptEnabled(true);
		caps.setCapability("requireWindowFocus", true);
		caps.setCapability("enablePersistentHover", false);
		driver = new InternetExplorerDriver(caps);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("file:///C:/Users/prav2435/Desktop/page/page/complete_registration.htm");
		Thread.sleep(3000);
		
		
		WebElement scroll = driver.findElement(By.id("step2_normal_language"));
		scroll.sendKeys(Keys.PAGE_UP);
		
		Thread.sleep(2000);
		driver.quit();
		
		
	}
	
	
	public static void main(String[] args) throws InterruptedException, IOException {
		
//		datePicker();
//		scrollSpecificElement();
//		uploadFilesUsingAutoIT();
		processKill();
//		createNewTicket();
//		editTicket();
//		checkTicketID();
//		checkDatePicker();
		
	}
	

}
