package com.plintron.crm;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class ModalPopup {
	
	public static void ieBrowserPopup() throws InterruptedException{
		
		
//		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		System.setProperty("webdriver.gecko.driver","input//geckodriver.exe");
		DesiredCapabilities cap = DesiredCapabilities.firefox();
		cap.setCapability("marionette", true);
//		WebDriver driver = new FirefoxDriver(cap);
		WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("file:///C:/Users/prav2435.PLINTRON.000/Desktop/Pages/Customer%20Relationship%20Management.html");
		Thread.sleep(3000);
		Object scrollBarPresent = ((JavascriptExecutor)driver).executeScript("return document.activeElement.getElementsByClassName('modal-footer')[0].innerHTML.trim()!=null;");
		System.out.println("Button :"+scrollBarPresent);
		
		Object textPresent = ((JavascriptExecutor)driver).executeScript("return document.activeElement.getElementsByClassName('modal-header')[0].innerHTML.trim()!=null;");
		System.out.println("Text :" +textPresent);
		
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		WebElement element = driver.findElement(By.xpath("//div[contains(text(), 'Ticket ID:')]"));
		System.out.println(jse.executeScript("return arguments[0].innerHTML;", element));
		driver.quit();
		
	}
	
	
	public static void firefoxPopup() throws InterruptedException{
		
		
//		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		System.setProperty("webdriver.gecko.driver","input//geckodriver.exe");
		DesiredCapabilities cap = DesiredCapabilities.firefox();
		cap.setCapability("marionette", true);
//		WebDriver driver = new FirefoxDriver(cap);
		WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("file:///C:/Users/prav2435.PLINTRON.000/Desktop/Pages/Customer%20Relationship%20Management.html");
		Thread.sleep(3000);

		WebElement popUpDisplay = driver.findElement(By.xpath("//button[@id='ErrmsgClose']/ancestor::div[@class='modal-content']"));
		System.out.println("************ isDisplay :"+popUpDisplay.isDisplayed());
		
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		WebElement element = driver.findElement(By.xpath("//div[contains(text(), 'Ticket ID:')]"));
		System.out.println(jse.executeScript("return arguments[0].innerHTML;", element));
		driver.quit();
		
	}
	
	
	

	public static void main(String[] args) throws InterruptedException {
		
//		ieBrowserPopup();
		firefoxPopup();
		
		
	}
	
	

}
