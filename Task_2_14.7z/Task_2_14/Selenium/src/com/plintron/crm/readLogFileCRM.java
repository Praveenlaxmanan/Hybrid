package com.plintron.crm;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;

public class readLogFileCRM {
	
	
	public static boolean readLog(){
		
		boolean elementStatus = false;
		
		String path = "input/";
		String startValue = "CRMServiceGBR_LYCA";
		String endValue = ".txt";
		String textValue = "449944002065";
		File[] listOfFile = null;
		String fileName = null;
		String actualText = null;
		Pattern pattern = null;
		
		try{
			
			File directory = new File(path);
			listOfFile = directory.listFiles();
			if(listOfFile.length != 0){
				
				for(int i=0; i<listOfFile.length; i++){
					if(listOfFile[i].isFile()){
						fileName = listOfFile[i].getName();
						if(fileName.startsWith(startValue) && fileName.endsWith(endValue)){
							System.out.println("Filename :"+fileName.toString());
							
						}
					}
				}
				
			}else{
				
				System.out.println("File is not available in directory");
				return false;
				
			}
			
			
			//Read the log file and match with expected text
			
			File file = new File(path+fileName);
			String fileContent = IOUtils.toString(file.toURI());
			
			actualText = "Text is not available in log file";
			pattern = Pattern.compile("449944002065");
			Matcher matcher = pattern.matcher(fileContent);
			
			while(matcher.find()){
				
				System.out.println("Value matched :"+matcher.group());
				return true;
			}
			
			System.out.println(actualText);
			
		}catch(Exception e){
			
			e.printStackTrace();
			return false;
			
		}
		
		return elementStatus;
		
	}
	
	
	public static boolean readLogFiles() throws Exception{
		
		boolean functionStatus = false;
		
		String path = "input/";
		String startValue = "CRMServiceGBR_LYCA";
		String endValue = ".txt";
		String textValue = "449944002065";
		File[] listOfFile = null;
		String fileName = null;
		String actualText = null;
		Pattern pattern = null;
		
		try{
			
			//Get the filename by given startName and endName
			
			File directory = new File(path);
			
//			System.out.println("directory :"+directory);
			
			listOfFile = directory.listFiles();
			
			if(listOfFile.length != 0){
			
			for(int i = 0; i<listOfFile.length; i++){
				
				if(listOfFile[i].isFile()){
					
					fileName = listOfFile[i].getName();
					
					if(fileName.startsWith(startValue) && fileName.endsWith(endValue)){
						
					}
					
				}
				
			}
			
			}else{
				
				System.out.println("File is not available in directory");
				return false;
				
				
			}
			
			//Read the file and match the expected value
			
			File ff = new File(path +fileName);
			
			String fileContent = IOUtils.toString(ff.toURI());
			
			System.out.println("fileContent :"+fileContent);
			
			actualText = "Text is not available in log file";
			
			pattern = Pattern.compile(textValue);
			Matcher matcher = pattern.matcher(fileContent);
			
			while(matcher.find()){
			actualText = matcher.group();
			System.out.println("Text is matched");
			return true;
			}
			
			System.out.println("Actual Regex text :"+actualText);
			System.out.println("Expected Regex text :"+pattern);
			
			System.out.println(actualText);
			functionStatus = false;
			
			
		}catch(Exception e){
			
			System.out.println("Exception occurs in read log file"+e.getMessage());
			functionStatus = false;
			
		}
		
		return functionStatus;
		
	}
	
	
	public static void main(String[] args) throws Exception {
		
//		readLog();
		readLogFiles();
	}
	

}
