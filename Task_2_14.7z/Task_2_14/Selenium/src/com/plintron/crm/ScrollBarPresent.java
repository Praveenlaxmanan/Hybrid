package com.plintron.crm;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class ScrollBarPresent {
	
	public static void checkScrollBarPresent() throws InterruptedException{
		
		System.setProperty("webdriver.ie.driver", "input//IEDriverServer.exe");
		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
		caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
		DesiredCapabilities.internetExplorer().setCapability("ignoreProtectedModeSettings", true);
		WebDriver driver = new InternetExplorerDriver(caps);
		/*System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		WebDriver driver = new ChromeDriver();*/
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://www.nullskull.com/q/10411434/fixed-header-and-footer-of-gridview-aspnet-c.aspx");
		Thread.sleep(3000);
		Object scrollBarPresent = ((JavascriptExecutor)driver).executeScript("return document.documentElement.scrollHeight>document.documentElement.clientHeight;");
		System.out.println("**** :"+scrollBarPresent);
		driver.quit();
		
	}

	public static void main(String[] args) throws InterruptedException {
		
		checkScrollBarPresent();
	}
	

}
