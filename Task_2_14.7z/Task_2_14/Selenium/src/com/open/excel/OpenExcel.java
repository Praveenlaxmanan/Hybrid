package com.open.excel;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;

public class OpenExcel {
	
	
	public static void fixError() throws IOException{
		
		String path = "C:/Users/prav2435.PLINTRON.000/Downloads/sample.xls";
		
		Workbook wb = null;
		System.out.print("Type i.e 2007+ if u wan2 create xlsx file (default xls) => ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String xlsx = br.readLine();
		if (xlsx.equalsIgnoreCase("xlsx"))
			wb = new XSSFWorkbook();
		else
			wb = new HSSFWorkbook();

		String excelFileName = path;
		if (wb instanceof XSSFWorkbook)
			excelFileName += "x";

		FileOutputStream fos = new FileOutputStream(excelFileName);
		wb.write(fos);
		fos.flush();
		fos.close();
		br.close();
		
		System.out.println("Success");
		
		
	}
	
	public static void main(String[] args) throws IOException {
		
		
		fixError();
		
		
	}
	

}
