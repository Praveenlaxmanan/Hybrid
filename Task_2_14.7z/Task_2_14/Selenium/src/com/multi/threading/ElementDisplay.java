package com.multi.threading;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class ElementDisplay {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.ie.driver", "input//IEDriverServer.exe");
		
		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
        caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
        WebDriver driver = new InternetExplorerDriver(caps);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.110.157:102/Pages/Login.aspx");
		driver.findElement(By.id("ctl00_cphMBOSDefault_txtUser")).sendKeys("admin");
		driver.findElement(By.id("ctl00_cphMBOSDefault_txtPassword")).sendKeys("123456");
		driver.findElement(By.id("ctl00_cphMBOSDefault_btnLogin")).click();
		
		Thread.sleep(5000);
		
		WebElement isDisplay = driver.findElement(By.xpath("//a//text()[normalize-space()='Sim']"));
		System.out.println(isDisplay.isDisplayed());
		driver.quit();
		
	}
	
	
}
