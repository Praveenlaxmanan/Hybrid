package com.multi.threading;

public class MainThread {
	
	static String s = "completed";
	
	static boolean b = false;
	
	public static void main(String[] args) throws InterruptedException {
		ThreadMoniter t = new ThreadMoniter();
		t.start();
		for(int i = 0; i < 5; i++){
			System.out.println("Main Thread is Running");
			Thread.sleep(2000);
			}
		System.out.println("Main Thread Completed");
		if(s.equalsIgnoreCase("completed")){
			b = true;
		}
		
	}
	
}