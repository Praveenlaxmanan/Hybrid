package com.multi.threading;

	public class ThreadMoniter extends Thread{	
		
		public void run(){
			
			while(!MainThread.b){
				
				System.out.println("Thread is Monitering");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			System.out.println("Thread is Not monitoring");
			
		}
		
	}
