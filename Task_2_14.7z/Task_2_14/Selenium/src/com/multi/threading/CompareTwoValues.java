package com.multi.threading;

import java.util.ArrayList;
import java.util.List;

public class CompareTwoValues {

	public static void compareArrayValues(){
		
		String array1[] = {"praveen", "naresh", "murali", "Anbu"};
		
		String array2[] = {"naresh", "anbu"};
		
		for(int i = 0; i < array1.length; i++){
			
			for(int j = 0; j < array2.length; j++){
				
				
				if(array1[i].equalsIgnoreCase(array2[j])){
					
					
					System.out.println(array1[i] +": Array one is matched with the Array two :"+array2[j]);
					
					
				}
				
				
			}
			
			
		}
		
		
	}
	
	
	
	public static void main(String[] args) {
		
		
		compareArrayValues();
		
	}
	
	
}
