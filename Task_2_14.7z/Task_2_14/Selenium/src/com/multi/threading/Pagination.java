package com.multi.threading;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Pagination {

	public static void webTablePagination(){
		
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.get("http://192.168.110.157:1503/Login/POSLogin.aspx");
		
		driver.findElement(By.id("UserName")).sendKeys("CPOS_WT_RET1");
		driver.findElement(By.id("Password")).sendKeys("12");
		driver.findElement(By.id("LoginButton")).click();
		driver.findElement(By.id("lnkMenu_23")).click();
		driver.findElement(By.xpath("//span[text()='Manage Child']")).click();
		
		List<WebElement> pages = driver.findElements(By.xpath("//*[@id='ctl00_ContentPlaceHolder1_grdChild']/tbody/tr[7]/td/table/tbody/tr/td/a"));
		
		System.out.println("pages :"+pages.size());
		
		for(int i = 2; i <= pages.size(); i++){
		
			try{	
			
		WebElement rudraText = driver.findElement(By.xpath("(//span[text()='WTSTAFF7'])[1]/parent::td/following-sibling::td/span[contains(@id,'MSISDN')]"));
		
		String text = "*********0021";
		
		if(rudraText.getText().equalsIgnoreCase(text)){
			
			System.out.println("Element is available");
			
		}
		
		}catch(NoSuchElementException e){
			
			
			WebElement checkText = driver.findElement(By.xpath("//*[@id='ctl00_ContentPlaceHolder1_grdChild']/tbody/tr[7]/td/table/tbody/tr/td["+i+"]/a"));
			
			checkText.click();
			
			
		
			}
	
		}
		
		
	}
	
	public static void main(String[] args) {
		
		webTablePagination();
		
	}
	
	
}
