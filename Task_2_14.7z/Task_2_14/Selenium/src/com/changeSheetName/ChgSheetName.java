package com.changeSheetName;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ChgSheetName {
	
	
	public static String filename;
	public static FileInputStream fis = null;
	public static HSSFWorkbook workbook = null;

	public static void changeSheetName(String path){

		try{
			fis = new FileInputStream(path);
			FileOutputStream fileOut = new FileOutputStream(path);
			fileOut.close();
			workbook = new HSSFWorkbook(fis);
			HSSFSheet sheet = workbook.getSheetAt(1);
			workbook.setSheetName(workbook.getSheetIndex(sheet), "123");
			workbook.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	

	
	
	public static void main(String[] args) {
		
		changeSheetName("C:/Users/prav2435.PLINTRON.000/Desktop/Test.xls");
		
	}

}