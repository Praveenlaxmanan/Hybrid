package com.changeSheetName;

public class TestConstructor {
	
	    int a;
	    int b;
	 
	    //Default constructor
	    TestConstructor()
	    {  
	    	this(30, 40);
	    	
	        System.out.println("Inside  default constructor \n");
	    }
	     
	    //Parameterized constructor
	    TestConstructor(int a, int b)
	    {
	        this.a = a;
	        this.b = b;
	        System.out.println("Inside parameterized constructor :"+a +" & "+b);
	    }
	 
	    public static void main(String[] args)
	    {
	    	TestConstructor object = new TestConstructor();
	    }
	}
