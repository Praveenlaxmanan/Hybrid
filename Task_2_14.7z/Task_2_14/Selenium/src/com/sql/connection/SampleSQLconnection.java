package com.sql.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class SampleSQLconnection {

		// JDBC driver name and database URL
		   //static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
			static final String JDBC_DRIVER = "com.sqlserver.jdbc.Driver";
		   //static final String DB_URL = "jdbc:mysql://192.168.110.87";
			//static final String DB_URL = "jdbc:sqlserver://192.168.110.87[DLFSQLLOAD]";
			
			static String sqlserver = "192.168.110.87";
			static String sqldbname = "MVNO_USA";
			static String dbUrl = "jdbc:sqlserver://"+ sqlserver +":DatabaseName=" + sqldbname +";";      
			
		   //jdbc:sqlserver://[serverName[\instanceName][:portNumber]][;property=value[;property=value]]				   

		   //  Database credentials
		   static final String USER = "SA";
		   static final String PASS = "SAlycatel123";
		   
		   public static void main(String[] args) {
		   Connection conn = null;
		   Statement stmt = null;
		   
		      //STEP 2: Register JDBC driver
		      try {
				//Class.forName("com.sqlserver.jdbc.Driver");
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				
				System.out.println("Unable to connect to the SQL server");
				
				e.printStackTrace();
			}

		      //STEP 3: Open a connection
		      System.out.println("Connecting to database...");
		      try {
				conn = DriverManager.getConnection(dbUrl,USER,PASS);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				
				System.out.println("SQL user name or Pwd is incorrect ");
				
				e.printStackTrace();
			}

		      //STEP 4: Execute a query
		      System.out.println("Creating statement...");
		      try {
				stmt = conn.createStatement();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				
				System.out.println("Unable to create the SQL statement ");
				
				e.printStackTrace();
			}
		      String sql;
		      sql = "SELECT * FROM MSTCUSTOMER WHERE MSISDN = '19076600000'";
		      ResultSet rs = null;
			try {
				rs = stmt.executeQuery(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				
				System.out.println("Unable to execute the SQL statement");
				
				e.printStackTrace();
			}

		      //STEP 5: Extract data from result set
		      try {
				while(rs.next()){
				     //Retrieve by column name
				     int id  = rs.getInt("id");
				     int msisdn = rs.getInt("msisdn");
				     String firstName = rs.getString("firstname");
				     String lastName = rs.getString("lastname");

				     //Display values
				     System.out.print("id : " + id);
				     System.out.print(", MSISDN : " + msisdn);
				     System.out.print(", First Name : " + firstName);
				     System.out.println(", Last Name : " + lastName);
				  }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     
		   System.out.println("Completed!");

	}

}
		   
		   

