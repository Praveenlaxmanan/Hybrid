package com.sql.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class newConnection {

	public static Connection con = null;
	public static Statement stmt = null;
	
	public static void openConnection(){
		
		try{
		
		String sqlserver = "192.168.110.84";
		String sqldbname = "MVNO_USA_AUTO";
		String sqlusername = "testlogin";
		String sqlpassword = "testlogin123";
		
		String dbUrl = "jdbc:sqlserver://"+ sqlserver +";DatabaseName=" + sqldbname +";";   
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		con = DriverManager.getConnection(dbUrl,sqlusername,sqlpassword);
		stmt = con.createStatement(); 
		System.out.println("Connection is opened");
		
		}catch(Exception e){
			
			
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		
		openConnection();
		
	}
	
	
	
	
}
