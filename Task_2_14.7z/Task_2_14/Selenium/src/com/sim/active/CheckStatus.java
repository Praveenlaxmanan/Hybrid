package com.sim.active;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckStatus {
	
	public static WebDriver driver;
	public static void radioButton(){
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.110.157:1503/Shops/");
		pageLoadCheck("POSLOGIN");
		driver.findElement(By.id("UserName")).sendKeys("CPOS_WT_RET1");
		driver.findElement(By.id("Password")).sendKeys("12");
		driver.findElement(By.id("LoginButton")).click();
		pageLoadCheck("CPOS");
		driver.findElement(By.id("lnkMenu_23")).click();
		pageLoadCheck("COM PARENT");
		driver.findElement(By.xpath("//span[text()='Credit Card Topup']")).click();
		driver.quit();
		
	}
	
	public static void pageLoadCheck(String pageTitle){
		
        String docStatus;
        JavascriptExecutor js = (JavascriptExecutor)driver;
        
        try {
        	
        	if(pageTitle.equalsIgnoreCase(driver.getTitle())){
        		
        		System.out.println("Page Title :"+driver.getTitle());
        		
              for (int i=0; i<60; i++){ 
              if(js.executeScript("return document.readyState").toString().equals("complete")){   
            	  docStatus= js.executeScript("return document.readyState").toString();
            	  System.out.println("Status :"+docStatus);
                     System.out.println("Page Loaded Successfully");
               //      System.out.println("Value in i is "+ i);
                     break;
              }
              
              else{
            	  
            	  docStatus= js.executeScript("return document.readyState").toString();
            	  System.out.println("Status :"+docStatus);
            	  Thread.sleep(1000);
              		
              		}
              }
             
              // Title is not matched
        	}else if(!(pageTitle.equalsIgnoreCase(driver.getTitle()))){
        		
        		System.out.println("Page title is not matched");
        		
        	}
              
        }catch(Exception e){
        	
        	
        }
		
	}
	
	
	public static void main(String[] args) {
		
		radioButton();
		
	}
	

}
