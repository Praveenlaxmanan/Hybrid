package com.sim.active;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectDate {

	public static WebDriver driver;
	
	public static void selectDateIncr() throws InterruptedException{
		
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.get("http://192.168.110.157:1503/Shops/");
		driver.findElement(By.id("UserName")).sendKeys("CPOS_WT_RET1");
		driver.findElement(By.id("Password")).sendKeys("12");
		driver.findElement(By.id("LoginButton")).click();
		driver.findElement(By.id("lnkMenu_23")).click();
		driver.findElement(By.xpath("//span[text()='Credit Card Topup']")).click();
		
		WebElement dropdown = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlCardExpiryYear"));
		
		Date date = new Date();
		
		String dateFormat = new SimpleDateFormat("yyyy").format(date);
		
		System.out.println(dateFormat);
		
		int convertedInt = Integer.parseInt(dateFormat) + 1;
		
		System.out.println(convertedInt);
		
		String convertedString = Integer.toString(convertedInt);
		
		System.out.println("convertedString :" +convertedString);
		
		WebElement month = driver.findElement(By.id("ctl00_ContentPlaceHolder1_ddlCardExpiryMonth")); 
		
		Select mon = new Select(month);
		
		String expMonthValues = mon.getFirstSelectedOption().getText();
		
		System.out.println("monthValue :" +expMonthValues);
		
		Select updatedDate = new Select(dropdown);
		
		updatedDate.selectByVisibleText(convertedString);
		
		String DBValues = "2017-01-31";

		String actualDropdownValue = convertedString+"-"+expMonthValues+"-";
		
		System.out.println("actualDropdownValue :" +actualDropdownValue);
		
		Pattern pat = Pattern.compile("("+actualDropdownValue+")(.*)");
		
		Matcher match = pat.matcher(DBValues);
		
		while(match.find()){
			
			System.out.println("Regex values :"+match.group(1)+match.group(2));
			break;
		}
		
		Thread.sleep(3000);

		driver.quit();
	}
	
	
	public static void currentDate(){
		
		Date date = new Date();
		
		String dateFormat = new SimpleDateFormat("yyyy").format(date);
		
		System.out.println(dateFormat);
		
	}
	
	public static void alertMessageCheck() throws InterruptedException{
		
		try{
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.get("http://192.168.110.157:1503/Shops/");
		driver.findElement(By.id("UserName")).sendKeys("CPOS_REG_RET1");
		driver.findElement(By.id("Password")).sendKeys("12");
		driver.findElement(By.id("LoginButton")).click();
		driver.findElement(By.id("lnkMenu_22")).click();
		driver.findElement(By.xpath("//*[@id='ctl00_ContentPlaceHolder1_divSubMenuList']/div[4]/div[1]/a/span")).click();
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_btnSubmit")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("ctl00_btnLogOut")).click();
		
		Thread.sleep(2000);
		
		driver.quit();
		
		}catch(Exception e){
			
			e.printStackTrace();
			
		}
		
	}
	
	

	public static void main(String[] args) throws InterruptedException {
		
//		selectDateIncr();
//		currentDate();
		alertMessageCheck();
		
		
	}
	
	
	
}
