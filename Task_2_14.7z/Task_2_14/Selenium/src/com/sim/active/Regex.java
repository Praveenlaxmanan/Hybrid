package com.sim.active;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regex {
	
	public static void successMessage(){
		
		
		String compileValue = "(Payment, Topup Success, TrnId - )(.*)( & RedOrderId - )(.*)( , InvoiceNumber : )(.*)(,and SMS Sent Successfully)";
		String matcherValue = "Payment, Topup Success, TrnId - COMC0000000163 & RedOrderId - US0000008000 , InvoiceNumber : IN044-S000000000138,and SMS Sent Successfully";
		
		Pattern pattern = Pattern.compile(compileValue);
		Matcher match = pattern.matcher(matcherValue);
		
		while(match.find()){
			
			String output = match.group(2)+match.group(4)+match.group(6)+match.group(7); 
			
			System.out.println(output);
			break;
			
		}
		
		
	}
	
	
	public static void regexPattern(){
		
		
		String compileValue = "\\d{4}-\\d{2}";
		String matcherValue = "2017-01-06";
		
		Pattern pattern = Pattern.compile(compileValue);
		Matcher match = pattern.matcher(matcherValue);
		
		while(match.find()){
			
			String output = match.group(); 
			
			System.out.println(output);
			break;
			
		}
		
		
		
	}
	
	
	public static void main(String[] args) {
		
		
//		successMessage();
		regexPattern();
		
	}
	
	
}
