package com.HLR;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.collect.Lists;

public class HLRFileUpload {
	
public static List<String> fileblackList= Lists.newArrayList();
public static List<String> fileDelete= Lists.newArrayList();
public static List<String> simUpload= Lists.newArrayList();

public static List<String> blackListedMsg= Lists.newArrayList();
public static List<String> simDeleteMsg= Lists.newArrayList();
public static List<String> simUploadMsg= Lists.newArrayList();


public static WebDriver driver;

	public static void loopIterationBlackList(String path){
		
		
		File[] listOfFile = null;
		String fileName = null;
		
		
		File directory = new File(path);
		listOfFile = directory.listFiles();
		if(listOfFile.length != 0){
			for(int i = 0; i<listOfFile.length; i++){
				if(listOfFile[i].isFile()){
					fileName = listOfFile[i].getAbsoluteFile().getAbsolutePath();
					System.out.println(fileName);
					fileblackList.add(fileName);
		
						}

					}
		
				}		
			
			}



	public static void loopIterationSimDelete(String path){
	
	
	File[] listOfFile = null;
	String fileName = null;
	
	
	File directory = new File(path);
	listOfFile = directory.listFiles();
	if(listOfFile.length != 0){
		for(int i = 0; i<listOfFile.length; i++){
			if(listOfFile[i].isFile()){
				fileName = listOfFile[i].getAbsoluteFile().getAbsolutePath();
				System.out.println(fileName);
				fileDelete.add(fileName);
	
					}

				}
	
			}		
		
		}

	
	
	public static void loopIterationSimUpload(String path){
		
		
		File[] listOfFile = null;
		String fileName = null;
		
		
		File directory = new File(path);
		listOfFile = directory.listFiles();
		if(listOfFile.length != 0){
			for(int i = 0; i<listOfFile.length; i++){
				if(listOfFile[i].isFile()){
					fileName = listOfFile[i].getAbsoluteFile().getAbsolutePath();
					System.out.println(fileName);
					simUpload.add(fileName);
		
						}

					}
		
				}		
			
			}
	

	/**
	 * 
	 * <Objective: This method is to upload the bulk files and do operation for Black Listed>
	 * @throws InterruptedException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	
	public static void hlrSimBlackList() throws InterruptedException, FileNotFoundException, IOException{
		
		
		try{
		
		System.setProperty("webdriver.ie.driver", "input//IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.110.151:4040/2.0.16.0_Rev_3/ContentPage/HlrLogin.aspx");
		driver.findElement(By.id("ctl00_cphLogin_txtName")).sendKeys("BLU2");
		driver.findElement(By.id("ctl00_cphLogin_txtPassword")).sendKeys("BLU2");
		waituntilExistXpath("//select[@id='ctl00_cphLogin_drpCountry']");
		selectByValue("//select[@id='ctl00_cphLogin_drpCountry']", "HLRHSS@STLOADB");
		RefreshObject("//select[@id='ctl00_cphLogin_ddlNetwork']");
		selectByValue("//select[@id='ctl00_cphLogin_ddlNetwork']", "1");
		driver.findElement(By.id("ctl00_cphLogin_btnLogin")).click();
		waituntilExistID("ctl00_imgPname");
		waituntilExistXpath("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/span");
		driver.findElement(By.xpath("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/span")).click();
		coordinates("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/ul/li[2]/a");
		waituntilExistXpath("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/ul/li[2]/a");
		coordinates("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/ul/li[2]/a");
		javaScriptClick("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/ul/li[2]/a");
		waituntilExistID("ctl00_cphContent_chkBulkUpload");
		driver.findElement(By.id("ctl00_cphContent_chkBulkUpload")).click();
		driver.findElement(By.id("ctl00_cphContent_rdoIMSI")).click();
		selectByText("//*[@id='ctl00_cphContent_ddlBulkFlag']", "Black Listed"); 
		
		
		loopIterationBlackList("delete/");
		
		for(int i= 0; i<fileblackList.size(); i++){
			
			driver.findElement(By.id("ctl00_cphContent_fnBulk")).sendKeys(fileblackList.get(i));
			driver.findElement(By.id("ctl00_cphContent_btnBulk")).click();
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alert.getText();
			alert.accept();
			waituntilExistID("ctl00_cphContent_lblSuccessMsg");
			String successMsg = driver.findElement(By.id("ctl00_cphContent_lblSuccessMsg")).getText();
			blackListedMsg.add(successMsg);
			System.out.println("successMsg Block *** "+i+":"+successMsg);
			
		}
		
		
		driver.quit();
		
		}catch(Exception e){
			
			
			System.out.println("Exception occurred, while black list the SIMs by IMSI" +e.getMessage());
			
		}
		
		
		try{
		
		blackListIMSIExcelSheet("C:/Users/prav2435.PLINTRON.000/Desktop/Sim_Black_Listed.xlsx");
		
		
		}catch(Exception e){
			
			
			System.out.println("Exception occurred, while writing the files for 'black list the SIMs by IMSI' status" +e.getMessage());
			
		}
		
		
		
	}
	
	
	public static void hlrSimDelete() throws InterruptedException, FileNotFoundException, IOException{
		
		
		try{
		
		System.setProperty("webdriver.ie.driver", "input//IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.110.151:4040/2.0.16.0_Rev_3/ContentPage/HlrLogin.aspx");
		driver.findElement(By.id("ctl00_cphLogin_txtName")).sendKeys("BLU2");
		driver.findElement(By.id("ctl00_cphLogin_txtPassword")).sendKeys("BLU2");
		waituntilExistXpath("//select[@id='ctl00_cphLogin_drpCountry']");
		selectByValue("//select[@id='ctl00_cphLogin_drpCountry']", "HLRHSS@STLOADB");
		RefreshObject("//select[@id='ctl00_cphLogin_ddlNetwork']");
		selectByValue("//select[@id='ctl00_cphLogin_ddlNetwork']", "1");
		driver.findElement(By.id("ctl00_cphLogin_btnLogin")).click();
		waituntilExistID("ctl00_imgPname");
		
		
		loopIterationSimDelete("deleteSim/");
		
		for(int i= 0; i<fileDelete.size(); i++){
			
			
			waituntilExistXpath("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/span");
			driver.findElement(By.xpath("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/span")).click();
			coordinates("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/ul/li[3]/a");
			waituntilExistXpath("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/ul/li[3]/a");
			coordinates("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/ul/li[3]/a");
			javaScriptClick("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/ul/li[3]/a");
			waituntilExistID("ctl00_cphContent_lblFileFormat");
			coordinates("//input[@id='ctl00_cphContent_chkBulkUpload']");
			driver.findElement(By.id("ctl00_cphContent_chkBulkUpload")).click();
			driver.findElement(By.id("ctl00_cphContent_rdoDelete")).click();
			driver.findElement(By.id("ctl00_cphContent_rdoIMSI")).click();
			
			
			
			driver.findElement(By.id("ctl00_cphContent_fnbulkAccount")).sendKeys(fileDelete.get(i));
			driver.findElement(By.id("ctl00_cphContent_btnUpload")).click();
			waituntilExistID("ctl00_cphContent_lblSuccessMsg");
			String successMsg = driver.findElement(By.id("ctl00_cphContent_lblSuccessMsg")).getText();
			simDeleteMsg.add(successMsg);
			System.out.println("successMsg Sim Delete *** "+i+":"+successMsg);
			
			
		}
		
		driver.quit();
		
		}catch(Exception e){
			
			e.printStackTrace();
			System.out.println("Exception occurred, while deleting SIMs by IMSI" +e.getMessage());
			
		}
		
		try{
		
		
		deleteIMSIExcelSheet("C:/Users/prav2435.PLINTRON.000/Desktop/Sim_Deleted.xlsx");
		
		
		}catch(Exception e){
			
			e.printStackTrace();
			System.out.println("Exception occurred, while writing the files for 'deleting SIMs by IMSI' status" +e.getMessage());
			
		}
		
	}
	
	
	
	
	public static void hlrSimUpload() throws InterruptedException, FileNotFoundException, IOException{
		
		
		try{
		
		System.setProperty("webdriver.ie.driver", "input//IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.110.151:4040/2.0.16.0_Rev_3/ContentPage/HlrLogin.aspx");
		driver.findElement(By.id("ctl00_cphLogin_txtName")).sendKeys("BLU2");
		driver.findElement(By.id("ctl00_cphLogin_txtPassword")).sendKeys("BLU2");
		waituntilExistXpath("//select[@id='ctl00_cphLogin_drpCountry']");
		selectByValue("//select[@id='ctl00_cphLogin_drpCountry']", "HLRHSS@STLOADB");
		RefreshObject("//select[@id='ctl00_cphLogin_ddlNetwork']");
		selectByValue("//select[@id='ctl00_cphLogin_ddlNetwork']", "1");
		driver.findElement(By.id("ctl00_cphLogin_btnLogin")).click();
		waituntilExistID("ctl00_imgPname");
		
		
		
		loopIterationSimUpload("upload/");
		
		for(int i= 0; i<simUpload.size(); i++){
			
			
			waituntilExistXpath("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/span");
			driver.findElement(By.xpath("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/span")).click();
			coordinates("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/ul/li[3]/a");
			waituntilExistXpath("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/ul/li[3]/a");
			coordinates("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/ul/li[3]/a");
			javaScriptClick("//*[@id='ctl00_hlrMenuCtrl_menuUser']/div/ul/li[7]/ul/li[3]/a");
			waituntilExistID("ctl00_cphContent_lblFileFormat");
			
			
			coordinates("//*[@id='ctl00_cphContent_chkBulkUpload']");
			driver.findElement(By.id("ctl00_cphContent_chkBulkUpload")).click();
			
			
			
			waituntilExistXpath("//*[@id='ctl00_cphContent_ddlFileFormat']");
			selectByText("//*[@id='ctl00_cphContent_ddlFileFormat']", "1R+9L - Max(9L+1R),Burnt(1L+1R)");
			
			waituntilExistXpath("//*[@id='ctl00_cphContent_ddlPrimaryIMSI']");
			selectByText("//*[@id='ctl00_cphContent_ddlPrimaryIMSI']", "IMSI 1");
			
			waituntilExistXpath("//*[@id='ctl00_cphContent_drpTemplate']");
			selectByText("//*[@id='ctl00_cphContent_drpTemplate']", "ALL_SSPROVISION");
			
			waituntilExistXpath("//*[@id='ctl00_cphContent_drpMsisdnAllocType']");
			selectByText("//*[@id='ctl00_cphContent_drpMsisdnAllocType']", "Home MSISDN");
			
			waituntilExistXpath("//*[@id='ctl00_cphContent_ddlAUCTemplate']");
			selectByText("//*[@id='ctl00_cphContent_ddlAUCTemplate']", "BLUCHER_AuC TEMPL");
			
			coordinates("//*[@id='ctl00_cphContent_chkBulkUpload']");
			driver.findElement(By.id("ctl00_cphContent_rdoAdd")).click();
			driver.findElement(By.id("ctl00_cphContent_fnbulkAccount")).sendKeys(simUpload.get(i));
			driver.findElement(By.id("ctl00_cphContent_btnUpload")).click();
			
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alert.getText();
			alert.accept();
			waituntilExistXpath("//*[@id='ctl00_cphContent_lblSuccessMsg']");
			String successMsg = driver.findElement(By.id("ctl00_cphContent_lblSuccessMsg")).getText();
			simUploadMsg.add(successMsg);
			System.out.println("successMsg add *** "+i+":"+successMsg);
			
			
		}
		
		
		driver.quit();
		
		}catch(Exception e){
			
			e.printStackTrace();
			System.out.println("Exception occurred, while uploading the SIM" +e.getMessage());
			
		}
		
		try{
		
		
			simUploadExcelSheet("C:/Users/prav2435.PLINTRON.000/Desktop/Sim_Uploaded.xlsx");
		
		}catch(Exception e){
			
			e.printStackTrace();
			System.out.println("Exception occurred, while writing the files for 'Uploading the SIM' status" +e.getMessage());
			
		}
		
	}
	
	
	
	
	public static void blackListIMSIExcelSheet(String filePath) throws FileNotFoundException, IOException{
		
		XSSFWorkbook workbook = new XSSFWorkbook();
		
		XSSFSheet sheet = workbook.createSheet("Sim_BlackList");
		Row createRow = sheet.createRow(0);
		
		createRow.createCell(0).setCellValue("S.No");
		createRow.createCell(1).setCellValue("FileName");
		createRow.createCell(2).setCellValue("Status");
		for(int a = 0;a<fileblackList.size();a++){
			createRow = sheet.createRow(a+1);
			for(int b=a;b<=a;b++){
				createRow.createCell(0).setCellValue(b+1);
				createRow.createCell(1).setCellValue(fileblackList.get(b));
				createRow.createCell(2).setCellValue(blackListedMsg.get(b));
			}
		}
		
		FileOutputStream fo = new FileOutputStream(filePath);
		workbook.write(fo);
		workbook.close();
				
	}
	
	
	
	public static void deleteIMSIExcelSheet(String filePath) throws FileNotFoundException, IOException{
		
		XSSFWorkbook workbook = new XSSFWorkbook();
		
		XSSFSheet sheet = workbook.createSheet("Sim_Delete");
		Row createRow = sheet.createRow(0);
		
		createRow.createCell(0).setCellValue("S.No");
		createRow.createCell(1).setCellValue("FileName");
		createRow.createCell(2).setCellValue("Status");
		for(int a = 0;a<fileDelete.size();a++){
			createRow = sheet.createRow(a+1);
			for(int b=a;b<=a;b++){
				createRow.createCell(0).setCellValue(b+1);
				createRow.createCell(1).setCellValue(fileDelete.get(b));
				createRow.createCell(2).setCellValue(simDeleteMsg.get(b));
			}
		}
		
		FileOutputStream fo = new FileOutputStream(filePath);
		workbook.write(fo);
		workbook.close();
				
	}
	
	
	public static void simUploadExcelSheet(String filePath) throws FileNotFoundException, IOException{
		
		XSSFWorkbook workbook = new XSSFWorkbook();
		
		XSSFSheet sheet = workbook.createSheet("Sim_Upload");
		Row createRow = sheet.createRow(0);
		
		createRow.createCell(0).setCellValue("S.No");
		createRow.createCell(1).setCellValue("FileName");
		createRow.createCell(2).setCellValue("Status");
		for(int a = 0;a<simUpload.size();a++){
			createRow = sheet.createRow(a+1);
			for(int b=a;b<=a;b++){
				createRow.createCell(0).setCellValue(b+1);
				createRow.createCell(1).setCellValue(simUpload.get(b));
				createRow.createCell(2).setCellValue(simUploadMsg.get(b));
			}
		}
		
		FileOutputStream fo = new FileOutputStream(filePath);
		workbook.write(fo);
		workbook.close();
				
	}
	
	public static boolean waituntilExistXpath(String element) throws InterruptedException{
		
		boolean elementStatus = false;
		
		try{
		
		WebDriverWait wait = new WebDriverWait(driver, 45);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element)));
		elementStatus = true;
		
		
		}catch(StaleElementReferenceException e1){

			System.out.println("StaleElementReferenceException function Catch block. Calling Refresh Object.");
			RefreshObject(element);

			if(driver.findElement(By.xpath(element)).isDisplayed()){
				return waituntilExistXpath(element);
			}else
			{
				elementStatus = false;
			}

		}
		catch(Exception e){
			
			e.printStackTrace();
			
		}
		
		return elementStatus;
	}
	
	
	public static boolean waituntilExistID(String element) throws InterruptedException{
		
		try{
		
		WebDriverWait wait = new WebDriverWait(driver, 45);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(element)));
		return true;
		
		
		}catch(Exception e){
			
			e.printStackTrace();
			
		}
		return false;
	}
	
	public static void selectByText(String element, String text){
		
		WebElement elementCheck = driver.findElement(By.xpath(element));
		
		Select se = new Select(elementCheck);
		se.selectByVisibleText(text);
		
	}
	
	public static boolean selectByValue(String element, String text){
		
		boolean elementStatus = false;
		
		try{
		
		WebElement elementCheck = driver.findElement(By.xpath(element));
		
		Select se = new Select(elementCheck);
		se.selectByValue(text);
		elementStatus = true;
		
		}catch(StaleElementReferenceException e){
			
			System.out.println("StaleElementReferenceException function Catch block. Calling Refresh Object.");
			RefreshObject(element);

			if(driver.findElement(By.xpath(element)).isDisplayed()){
				return selectByValue(element, text);
			}else
			{
				elementStatus = false;
			}
			
			
		}
		
	
		return elementStatus;
		
	}
	
	
	
	public static boolean mouseOver(String element){
		
		boolean elementStatus = false;
		
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath(element))).click().build().perform();
		elementStatus = true;
		
		return elementStatus;
		
	}
	
	public static boolean RefreshObject(String element){

		boolean refresh = false;

		try{
			System.out.println("RefreshObject function Try block");

			int a = 0;
			while(a < 25){
				Thread.sleep(1000);	
				driver.findElement(By.xpath(element));
				a++;

				if(driver.findElement(By.xpath(element)).isDisplayed()){
					refresh = true;
					System.out.println("Element is displayed by used refresh object");
					break;
				}

			}
		}catch(StaleElementReferenceException e){
			
			System.out.println("StaleElementReferenceException function Catch block. Calling Refresh Object.");
			RefreshObject(element);

			if(driver.findElement(By.xpath(element)).isDisplayed()){
				return RefreshObject(element);
			}else
			{
				refresh = false;
			}
		
		}
		
		catch(Exception e){
			System.out.println("While refreshing, element is not found.");
			refresh = false;

		}
		return refresh;

	}
	
	public static void coordinates(String element){
		
		
		WebElement value = driver.findElement(By.xpath(element));
		
		Coordinates coordinates = ((Locatable)value).getCoordinates();
		coordinates.onPage();
		coordinates.inViewPort();
		
	}
	
	
	public static void javaScriptClick(String element){
		
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", driver.findElement(By.xpath(element)));
		
	}
	
	

	
	public static void main(String[] args) throws InterruptedException, FileNotFoundException, IOException {
		
		hlrSimBlackList();
		hlrSimDelete();
		hlrSimUpload();
		
		
		
	}
	

}
