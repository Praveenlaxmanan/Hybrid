package com.HLR;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.collect.Lists;


public class SimUpload {

	public static WebDriver driver;
	
	public static List<String> f= Lists.newArrayList();
	public static List<String> status= Lists.newArrayList();

	public static List<String> fileBlock = Lists.newArrayList();
	public static List<String> fileDelete = Lists.newArrayList();
	public static List<String> fileAdd = Lists.newArrayList();
	
	
	public static void uploadFiles(){
		
		
		String path = "delete/";
		File[] listOfFile = null;
		String fileName = null;
		
		
		File directory = new File(path);
		listOfFile = directory.listFiles();
		if(listOfFile.length != 0){
			for(int i = 0; i<listOfFile.length; i++){
				if(listOfFile[i].isFile()){
					fileName = listOfFile[i].getName();
					
					f.add(fileName);
//					status.add("Pass");
					System.out.println(fileName);
					
		
						}

					}
		
				}		
			
			}
	
	
	public static void writeExcelSheet() throws FileNotFoundException, IOException{
		
		XSSFWorkbook workbook = new XSSFWorkbook();
		
		XSSFSheet sheet = workbook.createSheet("Sheet");
		Row createRow = sheet.createRow(0);
		
		createRow.createCell(0).setCellValue("S.No");
		createRow.createCell(1).setCellValue("FileName");
		createRow.createCell(2).setCellValue("Message");
		createRow.createCell(3).setCellValue("Status");
		for(int a = 0;a<f.size();a++){
			createRow = sheet.createRow(a+1);
			for(int b=a;b<=a;b++){
				createRow.createCell(0).setCellValue(b+1);
				createRow.createCell(1).setCellValue(f.get(b));
				createRow.createCell(3).setCellValue(status.get(b));
			}
		}
		
		FileOutputStream fo = new FileOutputStream("C:/Users/prav2435.PLINTRON.000/Desktop/Book2.xlsx");
		workbook.write(fo);
		workbook.close();
				
	}
	
	
	public static void hlrDeleteLog() throws InterruptedException{
		
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://192.168.110.151:4040/2.0.16.0_Rev_3/ContentPage/HlrLogin.aspx");
		driver.findElement(By.id("ctl00_cphLogin_txtName")).sendKeys("BLU2");
		driver.findElement(By.id("ctl00_cphLogin_txtPassword")).sendKeys("BLU2");
		selectText("//select[@id='ctl00_cphLogin_drpCountry']", "HLRHSS@STLOADB");
		waituntilExist("//select[@id='ctl00_cphLogin_ddlNetwork']");
		selectText("//select[@id='ctl00_cphLogin_ddlNetwork']", "BLUCHER");
		driver.findElement(By.id("ctl00_cphLogin_btnLogin")).click();
		
		
		
		//Block List the Sim by IMSI
		driver.findElement(By.xpath("//text()[normalize-space()='Subscriber Provisioning']/parent::span")).click();
		waituntilExist("//text()[normalize-space()='Black List/Cancel Location']/parent::a");
		driver.findElement(By.xpath("//text()[normalize-space()='Black List/Cancel Location']/parent::a")).click();
		driver.findElement(By.id("ctl00_cphContent_chkBulkUpload")).click();
		driver.findElement(By.id("ctl00_cphContent_rdoIMSI")).click();
		selectText("//*[@id='ctl00_cphContent_ddlBulkFlag']", "Black Listed"); 
		
		String path = "delete/";
		File[] listOfFile = null;
		String fileName = null;
		
		File directory = new File(path);
		listOfFile = directory.listFiles();
		if(listOfFile.length != 0){
			for(int i = 0; i<listOfFile.length; i++){
				if(listOfFile[i].isFile()){
					fileName = listOfFile[i].getName();
					
					System.out.println(fileName);
					
					driver.findElement(By.id("ctl00_cphContent_fnBulk")).sendKeys("C:/Users/prav2435.PLINTRON.000/Desktop/HLR/delete/"+fileName+"");
					driver.findElement(By.id("ctl00_cphContent_btnBulk")).click();
					
					WebDriverWait wait = new WebDriverWait(driver, 20);
					wait.until(ExpectedConditions.alertIsPresent());
					Alert alert = driver.switchTo().alert();
					alert.getText();
					alert.accept();
					waituntilExist("//*[@id='ctl00_cphContent_lblSuccessMsg']");
					String successMsg = driver.findElement(By.id("ctl00_cphContent_lblSuccessMsg")).getText();
					System.out.println("successMsg Block *** "+i+":"+successMsg);
					
						}

					}
		
				}
		
		
		//Delete the Sim by IMSI
		driver.findElement(By.xpath("//text()[normalize-space()='Subscriber Provisioning']/parent::span")).click();
		waituntilExist("//text()[normalize-space()='Create/Delete Subscriber']/parent::a");
		driver.findElement(By.xpath("//text()[normalize-space()='Create/Delete Subscriber']/parent::a")).click();
		driver.findElement(By.id("ctl00_cphContent_chkBulkUpload")).click();
		driver.findElement(By.id("ctl00_cphContent_rdoDelete")).click();
		driver.findElement(By.id("ctl00_cphContent_rdoIMSI")).click();
		
		
		listOfFile = directory.listFiles();
		if(listOfFile.length != 0){
			for(int i = 0; i<listOfFile.length; i++){
				if(listOfFile[i].isFile()){
					fileName = listOfFile[i].getName();
					
					System.out.println(fileName);
					
					driver.findElement(By.id("ctl00_cphContent_fnbulkAccount")).sendKeys("C:/Users/prav2435.PLINTRON.000/Desktop/HLR/delete/"+fileName+"");
					driver.findElement(By.id("ctl00_cphContent_btnUpload")).click();
					waituntilExist("//*[@id='ctl00_cphContent_lblSuccessMsg']");
					String successMsg = driver.findElement(By.id("ctl00_cphContent_lblSuccessMsg")).getText();
					System.out.println("successMsg delete *** "+i+":"+successMsg);
					
						}

					}
		
				}
		
		String pathUpload = "upload/";
		File[] listOfFileUpload = null;
		String fileNameUpload = null;
		File directoryUpload = new File(pathUpload);
		
		driver.findElement(By.xpath("//text()[normalize-space()='Subscriber Provisioning']/parent::span")).click();
		waituntilExist("//text()[normalize-space()='Create/Delete Subscriber']/parent::a");
		driver.findElement(By.xpath("//text()[normalize-space()='Create/Delete Subscriber']/parent::a")).click();	
		
		listOfFileUpload = directoryUpload.listFiles();
		if(listOfFileUpload.length != 0){
			for(int i = 0; i<listOfFileUpload.length; i++){
				if(listOfFileUpload[i].isFile()){
					fileNameUpload = listOfFileUpload[i].getName();
					
		WebElement element = driver.findElement(By.xpath("//*[@id='ctl00_cphContent_chkBulkUpload']"));
		
		Coordinates coordinates = ((Locatable)element).getCoordinates();
		coordinates.onPage();
		coordinates.inViewPort();
		
		driver.findElement(By.xpath("//*[@id='ctl00_cphContent_chkBulkUpload']")).click();
		
		
		waituntilExist("//*[@id='ctl00_cphContent_ddlFileFormat']");
		selectText("//*[@id='ctl00_cphContent_ddlFileFormat']", "1R+9L - Max(9L+1R),Burnt(1L+1R)");
		waituntilExist("//*[@id='ctl00_cphContent_ddlPrimaryIMSI']");
		selectText("//*[@id='ctl00_cphContent_ddlPrimaryIMSI']", "IMSI 1");
		waituntilExist("//*[@id='ctl00_cphContent_drpTemplate']");
		selectText("//*[@id='ctl00_cphContent_drpTemplate']", "ALL_SSPROVISION");
		waituntilExist("//*[@id='ctl00_cphContent_drpMsisdnAllocType']");
		selectText("//*[@id='ctl00_cphContent_drpMsisdnAllocType']", "Home MSISDN");
		waituntilExist("//*[@id='ctl00_cphContent_ddlAUCTemplate']");
		selectText("//*[@id='ctl00_cphContent_ddlAUCTemplate']", "BLUCHER_AuC TEMPL");
		
		
		driver.findElement(By.id("ctl00_cphContent_rdoAdd")).click();
		
					System.out.println(fileNameUpload);
					
					driver.findElement(By.id("ctl00_cphContent_fnbulkAccount")).sendKeys("C:/Users/prav2435.PLINTRON.000/Desktop/HLR/upload/"+fileNameUpload+"");
					driver.findElement(By.id("ctl00_cphContent_btnUpload")).click();
					WebDriverWait wait = new WebDriverWait(driver, 20);
					wait.until(ExpectedConditions.alertIsPresent());
					Alert alert = driver.switchTo().alert();
					alert.getText();
					alert.accept();
					waituntilExist("//*[@id='ctl00_cphContent_lblSuccessMsg']");
					String successMsg = driver.findElement(By.id("ctl00_cphContent_lblSuccessMsg")).getText();
					System.out.println("successMsg add *** "+i+":"+successMsg);
					
						}

					}
		
				}
		
		Thread.sleep(4000);
		
		driver.quit();
		
	}
	
	
	public static void selectText(String element, String text){
		
		WebElement elementCheck = driver.findElement(By.xpath(element));
		
		Select se = new Select(elementCheck);
		se.selectByVisibleText(text);
		
	}
	
	
	public static boolean waituntilExist(String element) throws InterruptedException{
		
		
		try{
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element)));
		return true;
		
		
		}catch(StaleElementReferenceException e){
			
			for(int i = 0; i<60; i++){
				
				Thread.sleep(1000);
				driver.findElement(By.xpath(element));
				
				if(driver.findElement(By.xpath(element)).isDisplayed()){
					
					return waituntilExist(element);
					
				}
				
			}
			
			
		}catch(Exception e){
			
			e.printStackTrace();
			
		}
		return false;
	}
	
	public static void main(String[] args) throws FileNotFoundException, IOException, InterruptedException {
//		List<String> l = Lists.newArrayList();
//		l.add("Praveen");
//		l.add("Basker");
		
//		uploadFiles();
//		writeExcelSheet();
		
		hlrDeleteLog();
	
	
	}
	
}