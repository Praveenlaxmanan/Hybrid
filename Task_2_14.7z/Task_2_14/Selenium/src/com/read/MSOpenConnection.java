package com.read;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MSOpenConnection {

	
	public static void openConnection() throws SQLException{
		
		try{
			
		String s1 = "jdbc:ucanaccess://";
		String IP = "\\192.168.110.157";
		String user = "INCHDLFBSSDC\\yoge1665";
		String pwd = "Plintron@010";
		
		
//		Connection connection=DriverManager.getConnection("jdbc:ucanaccess://C:/Users/prav2435.PLINTRON.000/Desktop/UCanAccess-3.0.6-bin/lib/CRM.mdb");
		
		Connection connection=DriverManager.getConnection("jdbc:ucanaccess://C:/Users/prav2435.PLINTRON.000/Desktop/UCanAccess-3.0.6-bin/lib/CRM.mdb");
		Statement statement = connection.createStatement();
		ResultSet rs = statement.executeQuery("select EN from Country where cid=1");
		
		while(rs.next()){
			
			System.out.println(rs.getString(1));
			
		}
		
		
		}catch(Exception e){
			
			e.printStackTrace();
			
			
		}
		
	}
	
	
	public static void main(String[] args) throws SQLException {
		
		openConnection();
		
	}
	
	
}
