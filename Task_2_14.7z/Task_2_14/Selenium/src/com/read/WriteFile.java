package com.read;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class WriteFile {
	
	
	
	public static void writeFiles(String name, String filePath){
		
		BufferedWriter writer = null;
		try
		{
		    writer = new BufferedWriter( new FileWriter(filePath));
		    
		    String s = name;
		    
		    System.out.println("******* :" +s);
		    
		    writer.write(s);

		}
		catch ( IOException e)
		{
		}
		finally
		{
		    try
		    {
		        if ( writer != null)
		        writer.close( );
		    }
		    catch ( IOException e)
		    {
		    }
		}
		
	}
		
		
	public static void main(String[] args) {
		
		
		writeFiles("Naresh_Yamaha_FZ", "D://test.txt");
		
	}
	
	
	

}
