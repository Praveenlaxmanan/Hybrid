package CPOS;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioButton {

	
	public static void radioBtn(){
		
		System.setProperty("webdriver.chrome.driver", "input//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("file:///C:/Users/prav2435.PLINTRON/Desktop/Registration.aspx.html");
		
		List<WebElement> element = driver.findElements(By.xpath("//table[@id='ctl00_ContentPlaceHolder1_Reg_FRA1_RegRadioButtonOption']/tbody/tr/td"));
		
		
		
		for(WebElement checkElement : element){
			
			String actualValue = checkElement.getText().trim();

			if(actualValue.equalsIgnoreCase("MSISDN")){
				
				checkElement.click();
				
				System.out.println("Passed");
				
				break;
				
			}else{
				
				System.out.println("Failed");
				
			}
		
		
		
		
	}
	
	}
	
	public static void main(String[] args) {
		
		
		radioBtn();
		
	}
	
}
