package com.framework.reports;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.framework.libraries.Wrappers;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ExtentReports {

//	public static WebDriver driver;

	com.relevantcodes.extentreports.ExtentReports reports;
	ExtentTest testLogger;
	
	
	public void initializeReports(){
		
		String reportPath = "Reports/Extent_Reports/"+"testReportNew"+".html";
		reports = new com.relevantcodes.extentreports.ExtentReports(reportPath);
		
		reports.addSystemInfo("HostName", "Praveen")
		.addSystemInfo("Environment", "Report Creation")
		.addSystemInfo("UserName", "Praveen Lakshmanan");
		reports.loadConfig(new File("src/com/framework/properties/extent-config.xml"));
		testLogger = reports.startTest("FirstTest");
		
	}
	
	@Test
	public void demoTestReport(){
		
		String reportPath = "Reports/Extent_Reports/"+"testReportNew"+".html";
		reports = new com.relevantcodes.extentreports.ExtentReports(reportPath);
		
		reports.addSystemInfo("HostName", "Praveen")
		.addSystemInfo("Environment", "Report Creation")
		.addSystemInfo("UserName", "Praveen Lakshmanan");
		reports.loadConfig(new File("src/com/framework/properties/extent-config.xml"));
		
		testLogger = reports.startTest("FirstTest");
		
		System.setProperty("webdriver.ie.driver", "BrowserDrivers/IEDriverServer.exe");
		/*Wrappers.driver = new InternetExplorerDriver();
		Wrappers.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Wrappers.driver.manage().window().maximize();
		Wrappers.driver.get("http://www.google.com");
		reportINFO("Browser is launched successfully");
		
		String title = Wrappers.driver.getTitle();
		
		if(title.equalsIgnoreCase("Google")){
			
			reportPASS("Page title is matched successfully");
			
		}
		
		Wrappers.driver.quit();*/
		
	}
	
	@AfterTest
	public void closeReports(){
		
		try{
			
			reports.endTest(testLogger);
			reports.flush();
			
			
		}catch(Exception e){
			e.printStackTrace();
			
		}
		
		
	}
	
	public void intializeReportConfigs(){
		
		
		
	}
	
	
	
	
	
	public void reportPASS(String testInfo){
		
		testLogger.log(LogStatus.PASS, testInfo);
	}
	
	public void reportFAIL(String testInfo, String screenshotPath){
		
		testLogger.log(LogStatus.FAIL, testInfo);
		testLogger.log(LogStatus.FAIL, testLogger.addScreenCapture(screenshotPath));
		
	}
	
	
	public void reportINFO(String testInfo){
		
		testLogger.log(LogStatus.INFO, testInfo);
		
	}
	
	public void reportERROR(String testInfo){
		
		testLogger.log(LogStatus.ERROR, testInfo);
		
	}
	
	
	public void reportWARNING(String testInfo){
		
		testLogger.log(LogStatus.WARNING, testInfo);
		
	}
	
	
	public String reportFailScreenshot(boolean screenshotStatus, WebDriver driver){
		
		
		try{
		
		String screenshotPath = "Reports/Extent_Reports/Screenshots/";
		
		if(!(new File(screenshotPath).exists())){
			
			System.out.println("Screenshot folder is not available, it's going to create the directory");
			new File(screenshotPath).mkdir();
			System.out.println("Screenshot folder is created is successfully");
		}
		
		if(screenshotStatus){
			
			
			String screenshotName = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss_a").format(new Date());
			
			File screenshotFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshotFile, new File(screenshotPath+screenshotName+".png"));
			
			System.out.println("screenshotName :"+screenshotName);
			
			File filename = new File(screenshotPath+screenshotName+".png");
			String absolutePath = filename.getAbsolutePath();
			
			return absolutePath;
			
			}
		
		}catch(Exception e){
			
			e.printStackTrace();
			
		}
		
		return null;
	}
	
	
	public static void main(String[] args) {
		
		
//		demoTestReport("testName");
	}
	
	
	
	
}