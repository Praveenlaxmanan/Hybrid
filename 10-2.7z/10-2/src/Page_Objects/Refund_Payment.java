package Page_Objects;

import java.util.Hashtable;

import wrappers.FunctionLibrary;

public class Refund_Payment extends FunctionLibrary{
	
	public static synchronized String Refund_Payment_Page(String locator){
		
		try{
			
			FunctionLibrary function = new FunctionLibrary();
		
			Hashtable<String, String> hs = new Hashtable<String, String>();
			
			hs.put("VAS_Bundle_Balance", "xpath#.//*[@id='bundleVasData']//th[contains(text(),'ErrorResources#en$Topup1')]/../td");
			hs.put("menu_Dropdown", "id#dropdownMenu1");
			
				String xpathValue = hs.get(locator);
				
				if(xpathValue.contains("contains(text()")){
					
					function.replaceXpathByResx(xpathValue);
					
					
				}else{
				
					System.out.println("********* :" +hs.get(locator));
					
			return hs.get(locator);

				}
			
		}catch(Exception e){
			log.info("Error occurred in POM classes :"+e);
			return null;
		}
		return null;
	}
	
	public static void main(String[] args) {
		
		Refund_Payment_Page("menu_Dropdown");
		
	}
	

}
