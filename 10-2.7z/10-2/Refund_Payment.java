package Page_Objects;

import java.io.File;
import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import wrappers.FunctionLibrary;

public class Refund_Payment extends FunctionLibrary{

	public static synchronized String Refund_Payment_Page(String locator){
		
		try{
		
			Hashtable<String, String> hs = new Hashtable<String, String>();
			
			hs.put("VAS_Bundle_Balance", "xpath#.//*[@id='bundleVasData']//th[contains(text(),'ErrorResources#en$Topup1')]/../td");
			
				String xpathValue = hs.get(locator);
				
				if(xpathValue.contains("contains(text()")){
					
					System.out.println("contains(text()");
					
					Pattern pattern = Pattern.compile("(.*)contains(.*)text(.*),'(.*)'");
					
					Matcher matcher = pattern.matcher(xpathValue);
					
					while(matcher.find()){
						
						String splittedXpath = matcher.group(4);
						
						System.out.println("splittedXpath :"+splittedXpath);
						

						Pattern patternXpath = Pattern.compile("(.*)#(.*)\\$(.*)");
						
						Matcher matchXpath = patternXpath.matcher(splittedXpath);
						
						while(matchXpath.find()){
							
							
							String fileName = matchXpath.group(1);
							String resxLanguageName = matchXpath.group(2);
							String Keyname = matchXpath.group(3);
							
							
							System.out.println("fileName :"+fileName);
							System.out.println("LanguageName :"+resxLanguageName);
							System.out.println("Keyname :"+Keyname);
							
							String filePath = "D:/Old Framework/Yogendra/CRM_Parallel_Framework_v3/Resources/"+fileName+"."+resxLanguageName+".resx";
							
							File file = new File(filePath);
							String commonAttribute = "root/data";
							String fullAttributewithName = commonAttribute+"[@name='"+Keyname+"']/value";
							DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
							DocumentBuilder builder = factory.newDocumentBuilder();
							Document document = builder.parse(file);
							document.getDocumentElement().normalize();
							XPath xpath = XPathFactory.newInstance().newXPath();
							NodeList nodeList = (NodeList)xpath.compile(fullAttributewithName).evaluate(document, XPathConstants.NODESET);
							String nodeValue = nodeList.item(0).getTextContent();
							System.out.println("nodeValue :"+nodeValue);
							
							
							String xpathPOMVal = hs.get(locator);
							System.out.println("xpathPOMVal :"+xpathPOMVal);
							String baseRefValue = fileName+"#"+resxLanguageName+"$"+Keyname;
							System.out.println("baseRefValue :"+baseRefValue);
							
							String replacedXpath = xpathPOMVal.replace(baseRefValue, nodeValue);
							
							System.out.println("replacedXpath :"+replacedXpath);
							return replacedXpath;
							
								}
						
							}
					
						}
				
			return hs.get(locator);

		}catch(Exception e){
			log.info("Error occurred in POM classes :"+e);
			return null;
		}
	}
	
	
	public static void main(String[] args) {
		
		Refund_Payment_Page("VAS_Bundle_Balance");
		
	}
	

}
